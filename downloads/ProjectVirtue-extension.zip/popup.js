(function () {
  "use strict";
  var C = window.VirtueCore;
  var settings = null;
  var $ = function (id) { return document.getElementById(id); };
  var tabId = null;

  // ---------------------------------------------------------------- settings
  function save() { chrome.storage.sync.set({ settings: settings }); }

  function load() {
    chrome.storage.sync.get("settings", function (r) {
      var s = (r && r.settings) || {};
      settings = Object.assign({}, C.DEFAULT_SETTINGS, s);
      settings.categories = Object.assign({}, C.DEFAULT_SETTINGS.categories, s.categories || {});
      render();
      refresh();
    });
  }

  function render() {
    $("enabled").checked = settings.enabled;
    document.querySelectorAll("[data-cat]").forEach(function (el) {
      el.checked = settings.categories[el.dataset.cat] !== false;
    });
    $("custom").value = settings.custom;
    $("allow").value = settings.allow;
    $("padBefore").value = settings.padBefore;
    $("padAfter").value = settings.padAfter;
    $("uploaderMode").value = settings.uploaderMode;
    $("sceneCategory").value = settings.sceneCategory;
    $("soundCues").value = settings.soundCues || "ask";
    $("violenceLevel").value = String(settings.violenceLevel || 2);
    $("violenceLevel").disabled = settings.categories.violence === false;
    $("censorCaptions").checked = settings.censorCaptions;
    $("showIndicator").checked = settings.showIndicator;
    $("useDatabase").checked = settings.useDatabase;
    $("useUnverified").checked = settings.useUnverified !== false;
    $("useUnverified").disabled = !settings.useDatabase;
    $("shareFindings").checked = C.canShare(settings);
    shareInfo();
    $("useSubtitles").checked = settings.useSubtitles !== false;
    showPads();
  }

  function showPads() {
    $("padBeforeV").textContent = (+settings.padBefore).toFixed(2) + "s";
    $("padAfterV").textContent = (+settings.padAfter).toFixed(2) + "s";
  }

  var timer = null;
  function later(fn, ms) { clearTimeout(timer); timer = setTimeout(fn, ms || 300); }

  function bind() {
    $("enabled").addEventListener("change", function (e) { settings.enabled = e.target.checked; save(); later(refresh); });
    document.querySelectorAll("[data-cat]").forEach(function (el) {
      el.addEventListener("change", function () { settings.categories[el.dataset.cat] = el.checked; save(); render(); later(refresh); });
    });
    ["custom", "allow"].forEach(function (id) {
      $(id).addEventListener("input", function (e) { settings[id] = e.target.value; later(function () { save(); later(refresh); }); });
    });
    ["padBefore", "padAfter"].forEach(function (id) {
      $(id).addEventListener("input", function (e) { settings[id] = +e.target.value; showPads(); later(save); });
    });
    [["uploaderMode", "value"], ["sceneCategory", "value"], ["soundCues", "value"]].forEach(function (p) {
      $(p[0]).addEventListener("change", function (e) { settings[p[0]] = e.target[p[1]]; save(); later(refresh); });
    });
    $("violenceLevel").addEventListener("change", function (e) { settings.violenceLevel = +e.target.value; save(); later(refresh); });
    ["censorCaptions", "showIndicator", "useDatabase", "useSubtitles", "useUnverified"].forEach(function (id) {
      $(id).addEventListener("change", function (e) { settings[id] = e.target.checked; save(); render(); later(refresh); });
    });
    // Sharing needs a clear yes first. Turning it off also withdraws the consent.
    $("shareFindings").addEventListener("change", function (e) {
      if (e.target.checked) { e.target.checked = false; $("consentBox").hidden = false; return; }
      settings.shareFindings = false; settings.shareConsentAt = null; save(); render();
    });
    $("consentYes").addEventListener("click", function () {
      settings.shareFindings = true; settings.shareConsentAt = new Date().toISOString();
      $("consentBox").hidden = true; save(); render();
    });
    $("consentNo").addEventListener("click", function () { $("consentBox").hidden = true; render(); });
    $("submitTags").addEventListener("click", submitTags);
    $("sendCode").addEventListener("click", sendCode);
    $("verify").addEventListener("click", verify);
    $("code").addEventListener("keydown", function (e) { if (e.key === "Enter") verify(); });
    $("signOut").addEventListener("click", function () { db("signOut", []).then(account); });
    $("openReview").addEventListener("click", function () { chrome.tabs.create({ url: chrome.runtime.getURL("review.html") }); });
    $("googleSignIn").addEventListener("click", function () {
      $("acctMsg").textContent = "Opening Google sign-in…";
      db("googleSignIn", []).then(function () { $("acctMsg").textContent = ""; account(); refresh(); showPlan(true); })
        .catch(function (e) { $("acctMsg").textContent = e.message; });
    });
    $("subscribe").addEventListener("click", function () { billing("checkout"); });
    $("manageBilling").addEventListener("click", function () { billing("billingPortal"); });
  }

  var signedIn = false;

  // ---------------------------------------------------------------- plan & free trial
  function showPlan(fresh) {
    chrome.runtime.sendMessage({ type: "virtue-entitlement", fresh: !!fresh }, function (e) {
      if (chrome.runtime.lastError || !e || !e.paywall) { $("planCard").hidden = true; return; }
      $("planCard").hidden = false;
      $("planName").textContent = e.planName + (e.priceLabel && !e.subscribed ? " · " + e.priceLabel : "");
      $("trialLine").textContent = C.trialLine(e);
      $("trialLine").className = e.allowed ? "" : "warnText";
      $("subscribe").hidden = e.subscribed;
      $("manageBilling").hidden = !e.subscribed;
    });
  }
  function billing(op) {
    if (!signedIn) { $("planMsg").textContent = "Sign in below first, so your subscription is linked to your account."; return; }
    $("planMsg").textContent = "Opening secure checkout…";
    db(op, [null]).then(function (r) {
      if (r && r.url) { chrome.tabs.create({ url: r.url }); $("planMsg").textContent = ""; }
      else $("planMsg").textContent = "Payments aren't set up yet.";
    }).catch(function (e) { $("planMsg").textContent = /not found|404/i.test(e.message) ? "Payments aren't set up yet." : e.message; });
  }
  function shareInfo() {
    var el = $("shareInfo");
    if (!C.canShare(settings)) { el.textContent = ""; return; }
    var since = new Date(settings.shareConsentAt).toLocaleDateString();
    if (!signedIn) { el.textContent = "Sharing is on (you agreed " + since + "). Sign in below so it can start."; return; }
    db("shareStats", []).then(function (s) {
      el.textContent = "Sharing is on (you agreed " + since + ") · " + s.finds + " find" + (s.finds === 1 ? "" : "s") +
        " shared from " + s.titles + " video" + (s.titles === 1 ? "" : "s") + "/title" + (s.titles === 1 ? "" : "s") + ".";
    }).catch(function () { el.textContent = "Sharing is on (you agreed " + since + ")."; });
  }

  // "Not verified" notice for what's playing.
  function showVerify(st) {
    var el = $("verifyNote"), v = st && st.verify;
    if (!settings.enabled || !v || !st.verifyMessage || v.state === "none") { el.hidden = true; return; }
    el.hidden = false;
    el.textContent = (v.state === "verified" ? "✓ " : "⚠ ") + st.verifyMessage;
    el.className = "status " + (v.state === "verified" ? "ok" : "warn");
  }

  // ---------------------------------------------------------------- talking to the tab / background
  function db(op, args) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage({ type: "db", op: op, args: args }, function (r) {
        if (chrome.runtime.lastError || !r) reject(new Error("Extension background isn't responding."));
        else if (!r.ok) reject(new Error(r.error));
        else resolve(r.res);
      });
    });
  }

  function toTab(msg) {
    return new Promise(function (resolve) {
      if (tabId === null) return resolve(null);
      chrome.tabs.sendMessage(tabId, msg, function (r) { resolve(chrome.runtime.lastError ? null : r); });
    });
  }

  function setStatus(text, cls) {
    var s = $("status");
    s.textContent = text;
    s.className = "status " + (cls || "");
  }

  // popup.html?tab=<id> shows a specific tab (used by the automated tests).
  var forcedTab = +(new URLSearchParams(location.search).get("tab") || 0) || null;

  function refresh() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs[0];
      tabId = forcedTab || (tab ? tab.id : null);
      toTab({ type: "status" }).then(function (st) {
        $("streamCard").hidden = true;
        $("listCard").hidden = true;
        if (!st) {
          setStatus("Open a YouTube video, or a movie or show on a streaming service. (Already on one? Reload the tab.)", "");
          return;
        }
        if (st.kind === "stream") showStream(st); else showYouTube(st);
        showVerify(st);
      });
    });
  }

  // ---------------------------------------------------------------- YouTube
  function showYouTube(st) {
    if (!settings.enabled) { setStatus("Filtering is off.", "warn"); return; }
    if (st.locked) { setStatus(C.trialLine(st.entitlement) || "Your free trial is over.", "warn"); return; }
    if (!st.videoId) { setStatus("Open a YouTube video to start.", ""); return; }
    if (st.phase === "loading") { setStatus("Loading captions…", ""); setTimeout(refresh, 700); return; }
    var n = st.intervals.length;
    if (st.phase === "error" && !n) { setStatus(st.message || "Couldn't read captions for this video.", "warn"); return; }

    var caps = st.sources.indexOf("asr") >= 0
      ? (st.sources.indexOf("manual") >= 0 ? "auto + uploader captions" : "auto captions")
      : st.sources.indexOf("manual") >= 0 ? "uploader captions" : "";
    var src = [caps, st.sources.indexOf("database") >= 0 ? "the shared database" : ""].filter(Boolean).join(" + ");
    setStatus("Active · " + n + " mute" + (n === 1 ? "" : "s") + " from " + src +
      (st.audio === "precise" ? "" : " · click the video once for precise muting"), "ok");

    var list = $("list");
    list.innerHTML = "";
    $("count").textContent = "(" + n + ")";
    $("listCard").hidden = n === 0;
    st.intervals.forEach(function (iv) {
      var li = row(iv.start, iv.text, iv.end < st.currentTime);
      if (iv.estimated) li.appendChild(chip("approx", "", "Timing estimated from the uploader's captions"));
      if (iv.unverified) li.appendChild(chip("not verified", "pending", "From the shared database; a verified reviewer hasn't checked it yet"));
      li.title = "Jump to 3 seconds before";
      li.addEventListener("click", function () { toTab({ type: "seek", t: iv.start - 3 }); });
      list.appendChild(li);
    });
  }

  // ---------------------------------------------------------------- movies & TV
  var SERVICE_NAMES = { netflix: "Netflix", prime: "Prime Video", disney: "Disney+", max: "Max", hulu: "Hulu",
    peacock: "Peacock", paramount: "Paramount+", appletv: "Apple TV+" };
  var CAT_NAMES = { strong: "Strong", mild: "Mild", blasphemy: "God's name", slurs: "Slur", censored: "Bleeped",
    custom: "Custom", nudity: "Nudity", sexual: "Sexual", violence: "Violence", other: "Other" };
  var lastStream = null;

  function showStream(st) {
    lastStream = st;
    $("streamCard").hidden = false;
    $("streamService").textContent = "· " + (SERVICE_NAMES[st.service] || st.service) + (st.serviceId ? " #" + st.serviceId : "");
    if (!settings.enabled) setStatus("Filtering is off.", "warn");
    else if (st.locked) setStatus(C.trialLine(st.entitlement) || "Your free trial is over.", "warn");
    else if (!st.serviceId) setStatus("Start playing something and Virtue will look it up.", "");
    else if (st.phase === "loading") { setStatus("Looking up this title…", ""); setTimeout(refresh, 700); }
    else if (st.phase === "error") setStatus("Couldn't reach the database (" + st.error + "). Your own tags still work.", "warn");
    else if (st.phase === "offline") setStatus("Database not connected. Your own tags still work on this computer.", "warn");
    else if (!st.clockReady) setStatus("Syncing with the player's clock… (press play)", "");
    else {
      var applied = st.segments.filter(function (s) { return settings.categories[s.category === "censored" ? "strong" : s.category] !== false; }).length;
      var sub = st.subtitles || {};
      var subNote = !settings.useSubtitles ? "" : sub.lines ? " · " + sub.mutes + " swear" + (sub.mutes === 1 ? "" : "s") + " from subtitles"
        : " · turn on subtitles for word muting";
      var hints = (st.hints || []).length;
      if (hints && settings.soundCues !== "off") subNote += " · " + hints + " possible scene" + (hints === 1 ? "" : "s") + " spotted";
      setStatus("Active · " + applied + " filter" + (applied === 1 ? "" : "s") + (st.inDatabase ? "" : " · not in the database yet") + subNote, "ok");
    }

    var nameBox = $("titleName");
    if (document.activeElement !== nameBox) nameBox.value = (st.title && st.title.name) || st.guess.name || "";
    nameBox.disabled = !!st.inDatabase;
    nameBox.title = st.inDatabase ? "Already in the database" : "";

    var list = $("streamList");
    list.innerHTML = "";
    st.segments.forEach(function (s) {
      var li = row(s.start, (s.action === "skip" ? "Skip " : "") + (s.label && s.label !== "scene" && s.label !== "marked" ? s.label : ""), s.end < st.now);
      li.insertBefore(span("act", s.action === "skip" ? "⏭" : "\u{1F507}"), li.children[1]);
      if (s.local) {
        var sel = document.createElement("select");
        var cats = s.action === "skip" ? ["nudity", "sexual", "violence", "other"] : ["strong", "mild", "blasphemy", "slurs", "custom"];
        cats.forEach(function (c) { var o = document.createElement("option"); o.value = c; o.textContent = CAT_NAMES[c]; sel.appendChild(o); });
        sel.value = s.category;
        sel.addEventListener("click", function (e) { e.stopPropagation(); });
        sel.addEventListener("change", function () { toTab({ type: "tag-update", index: s.index, patch: { category: sel.value } }).then(refresh); });
        li.appendChild(sel);
        li.appendChild(chip("new", "new"));
        var del = document.createElement("button");
        del.className = "del"; del.textContent = "✕"; del.title = "Remove this tag";
        del.addEventListener("click", function (e) { e.stopPropagation(); toTab({ type: "tag-update", index: s.index, remove: true }).then(refresh); });
        li.appendChild(del);
      } else {
        li.appendChild(span("chipwrap", ""));
        li.lastChild.appendChild(chip(CAT_NAMES[s.category] || s.category, ""));
        if (s.source === "cues" && s.status !== "approved") li.appendChild(chip("guess", "pending", "Spotted from sound cues in the subtitles; not checked by a reviewer yet"));
        else if (s.status === "pending") li.appendChild(chip("not verified", "pending", "A verified reviewer hasn't checked this one yet"));
      }
      li.title = "Jump to 3 seconds before";
      li.addEventListener("click", function () { toTab({ type: "seek", t: s.start - 3 }); });
      list.appendChild(li);
    });
    $("streamEmpty").hidden = st.segments.length > 0;
    $("submitRow").hidden = !st.localCount;
    $("submitTags").textContent = "Submit " + st.localCount + " new tag" + (st.localCount === 1 ? "" : "s") + " for review";
  }

  function submitTags() {
    var name = $("titleName").value.trim();
    if (!lastStream.inDatabase && !name) { $("submitMsg").textContent = "Add the title's name first."; return; }
    $("submitTags").disabled = true;
    $("submitMsg").textContent = "Sending…";
    toTab({ type: "submit", title: name ? { name: name } : {} }).then(function (r) {
      $("submitTags").disabled = false;
      if (r && r.ok) $("submitMsg").textContent = "Thanks! " + r.res.submitted + " tag(s) sent. They'll apply for everyone once a reviewer approves them.";
      else $("submitMsg").textContent = (r && r.error) || "Couldn't submit.";
      refresh();
    });
  }

  // ---------------------------------------------------------------- shared list bits
  function row(t, text, past) {
    var li = document.createElement("li");
    if (past) li.className = "past";
    var time = document.createElement("time");
    time.textContent = C.fmtTime(t);
    li.appendChild(time);
    li.appendChild(span("what", text));
    return li;
  }
  function span(cls, text) { var s = document.createElement("span"); s.className = cls; s.textContent = text; return s; }
  function chip(text, cls, title) { var c = span("chip " + (cls || ""), text); if (title) c.title = title; return c; }

  // ---------------------------------------------------------------- settings profiles
  var prof = null, profMode = null;
  var DEVICE_ONLY = "__device__";
  function profMsg(t) { $("profMsg").textContent = t || ""; }
  function showProfiles(r) {
    prof = r;
    $("profOut").hidden = !!(r && r.signedIn);
    $("profIn").hidden = !(r && r.signedIn);
    if (!r || !r.signedIn) return;
    var sel = $("profSelect");
    sel.innerHTML = "";
    r.profiles.forEach(function (p) {
      var o = document.createElement("option");
      o.value = p.id; o.textContent = p.name + (p.isDefault ? " (default)" : "");
      sel.appendChild(o);
    });
    var only = document.createElement("option");
    only.value = DEVICE_ONLY; only.textContent = "This browser only (not synced)";
    sel.appendChild(only);
    sel.value = r.activeId || DEVICE_ONLY;
    var active = r.profiles.filter(function (p) { return p.id === r.activeId; })[0];
    $("profRename").disabled = $("profDelete").disabled = !active;
    $("profDefault").disabled = !active || active.isDefault;
    profMsg(active ? "Changes you make here are saved to \"" + active.name + "\" and reach every device using it."
      : "Settings here stay on this browser.");
  }
  function profiles(op, args, done) {
    profMsg("Saving…");
    return db(op, args || []).then(function (r) { showProfiles(r); load(); if (done) profMsg(done); })
      .catch(function (e) { profMsg(e.message); });
  }
  function loadProfiles() { db("profileList", []).then(showProfiles).catch(function (e) { showProfiles(null); profMsg(e.message); }); }
  function closeProfForms() { $("profNameRow").hidden = true; $("profDeleteRow").hidden = true; profMode = null; }
  function bindProfiles() {
    $("profSelect").addEventListener("change", function (e) {
      closeProfForms();
      var v = e.target.value;
      profiles("profileUse", [v === DEVICE_ONLY ? null : v], v === DEVICE_ONLY ? "This browser now keeps its own settings." : "Switched. This browser now uses that profile.");
    });
    $("profNew").addEventListener("click", function () {
      closeProfForms(); profMode = "new";
      $("profName").value = ""; $("profFreshRow").hidden = false; $("profFresh").checked = false;
      $("profNameRow").hidden = false; $("profName").focus();
    });
    $("profRename").addEventListener("click", function () {
      closeProfForms(); profMode = "rename";
      $("profName").value = prof && prof.activeName || ""; $("profFreshRow").hidden = true;
      $("profNameRow").hidden = false; $("profName").focus();
    });
    $("profCancel").addEventListener("click", closeProfForms);
    function saveName() {
      var name = $("profName").value.trim();
      if (!name) { profMsg("Give the profile a name."); return; }
      var mode = profMode;
      closeProfForms();
      if (mode === "new") profiles("profileCreate", [name, { fresh: $("profFresh").checked }], "Made \"" + name + "\". This browser now uses it.");
      else if (mode === "rename") profiles("profileRename", [prof.activeId, name], "Renamed.");
    }
    $("profSave").addEventListener("click", saveName);
    $("profName").addEventListener("keydown", function (e) { if (e.key === "Enter") saveName(); });
    $("profDefault").addEventListener("click", function () {
      profiles("profileDefault", [prof.activeId], "New devices you sign in on will start with this profile.");
    });
    $("profDelete").addEventListener("click", function () {
      closeProfForms();
      $("profDeleteQ").textContent = "Delete \"" + (prof && prof.activeName) + "\"? Devices using it keep their current settings but stop syncing.";
      $("profDeleteRow").hidden = false;
    });
    $("profDeleteNo").addEventListener("click", closeProfForms);
    $("profDeleteYes").addEventListener("click", function () { var id = prof.activeId; closeProfForms(); profiles("profileDelete", [id], "Deleted."); });
  }

  // ---------------------------------------------------------------- account
  function account() {
    db("account", []).then(function (a) {
      $("acctOff").hidden = a.configured;
      $("acctOut").hidden = !a.configured || a.signedIn;
      $("acctIn").hidden = !a.signedIn;
      signedIn = !!a.signedIn;
      shareInfo();
      if (a.signedIn) loadProfiles(); else showProfiles({ signedIn: false });
      if (a.signedIn) {
        $("acctEmail").textContent = a.email;
        $("acctRole").textContent = a.role;
        $("openReview").hidden = ["reviewer", "admin"].indexOf(a.role) < 0;
      }
    }).catch(function (e) {
      $("acctOff").hidden = true; $("acctIn").hidden = true; $("acctOut").hidden = false;
      $("acctMsg").textContent = e.message;
    });
  }

  function sendCode() {
    var email = $("email").value.trim();
    if (!/^\S+@\S+\.\S+$/.test(email)) { $("acctMsg").textContent = "Enter your email address."; return; }
    $("sendCode").disabled = true;
    $("acctMsg").textContent = "Sending…";
    db("sendCode", [email]).then(function () {
      $("codeRow").hidden = false;
      $("code").focus();
      $("acctMsg").textContent = "Check your email. Right-click “Sign in” → Copy link, then paste it above. (If the email shows a code instead, paste that.)";
    }).catch(function (e) { $("acctMsg").textContent = e.message; })
      .then(function () { $("sendCode").disabled = false; });
  }

  function verify() {
    $("verify").disabled = true;
    db("verifyCode", [$("email").value.trim(), $("code").value.trim()]).then(function () {
      $("acctMsg").textContent = "";
      $("codeRow").hidden = true;
      account();
      refresh();
    }).catch(function (e) { $("acctMsg").textContent = e.message; })
      .then(function () { $("verify").disabled = false; });
  }

  bind();
  load();
  bindProfiles();
  // Settings changed by a profile switch or another device: show them.
  chrome.storage.onChanged.addListener(function (ch, area) {
    if (area !== "sync" || !ch.settings || !settings) return;
    if (JSON.stringify(ch.settings.newValue) === JSON.stringify(settings)) return;
    load();
  });
  account();
  showPlan(false);
  setInterval(function () { if (!document.hidden && document.activeElement.tagName !== "SELECT") refresh(); }, 2000);
})();
