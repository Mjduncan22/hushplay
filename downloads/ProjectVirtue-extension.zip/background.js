/*
 * Project Virtue - background worker
 * Owns the database connection and the sign-in session, so pages and the
 * popup all share one. Pages ask it with:
 *   chrome.runtime.sendMessage({ type: "db", op: "lookup", args: [service, id] })
 */
importScripts("config.js", "db.js", "core.js", "profiles.js");

var storage = {
  get: function (k) { return chrome.storage.local.get(k).then(function (r) { return r[k]; }); },
  set: function (k, v) { var o = {}; o[k] = v; return chrome.storage.local.set(o); }
};
var db = VirtueDB.create(self.VIRTUE_CONFIG, storage);

// Short cache so switching tabs / episodes doesn't hammer the database.
var cache = new Map();
var CACHE_MS = 5 * 60 * 1000;
var OPS = ["lookup", "submit", "pending", "review", "vote", "sendCode", "verifyCode", "signOut", "account", "share", "shareStats",
  "googleSignIn", "entitlement", "checkout", "billingPortal",
  "profileList", "profileUse", "profileCreate", "profileRename", "profileDelete", "profileDefault"];

// ---- free trial: count filtered watching time, sync it to the account when signed in
var USAGE_KEY = "virtue.usage", PLAN_KEY = "virtue.plan", CONFIG_KEY = "virtue.config";
var lastSync = 0;
async function getUsage() { return (await storage.get(USAGE_KEY)) || { total: 0, unsynced: 0 }; }
async function getConfig(fresh) {
  var c = await storage.get(CONFIG_KEY);
  if (!fresh && c && Date.now() - c.at < 60 * 60 * 1000) return c.value;
  if (!db.configured) return {};
  try { var v = await db.config(); await storage.set(CONFIG_KEY, { at: Date.now(), value: v }); return v; }
  catch (e) { return (c && c.value) || {}; }
}
async function getPlan(fresh) {
  var c = await storage.get(PLAN_KEY);
  if (!fresh && c && Date.now() - c.at < 10 * 60 * 1000) return c.value;
  if (!db.configured) return null;
  try { var v = await db.myPlan(); await storage.set(PLAN_KEY, { at: Date.now(), value: v }); return v; }
  catch (e) { return (c && c.value) || null; }
}
async function addUsage(seconds) {
  seconds = Math.max(0, Math.min(120, +seconds || 0));
  var plan = await getPlan(false);
  if (plan && plan.subscribed) return;   // Virtue Plus: no free trial to count
  var u = await getUsage();
  u.total += seconds; u.unsynced += seconds;
  await storage.set(USAGE_KEY, u);
  if (u.unsynced >= 300 || Date.now() - lastSync > 10 * 60 * 1000) await syncUsage();
}
async function syncUsage() {
  lastSync = Date.now();
  if (!db.configured || !(await db.signedIn())) return;
  var u = await getUsage();
  var send = u.unsynced;
  try {
    var plan = send > 0 ? await db.addUsage(Math.min(send, 3600)) : await db.myPlan();
    var u2 = await getUsage();
    u2.unsynced = Math.max(0, u2.unsynced - Math.min(send, 3600));
    await storage.set(USAGE_KEY, u2);
    await storage.set(PLAN_KEY, { at: Date.now(), value: plan });
  } catch (e) {}
}
async function entitlement(fresh) {
  return VirtueCore.entitlement(await getUsage(), await getPlan(fresh), await getConfig(fresh));
}
db.entitlement = function (fresh) { return entitlement(!!fresh); };

// ---- sign in with Google (Chrome's sign-in window, then the address it returns)
db.googleSignIn = function () {
  return new Promise(function (resolve, reject) {
    var redirect = chrome.identity.getRedirectURL("auth");
    chrome.identity.launchWebAuthFlow({ url: db.oauthUrl("google", redirect), interactive: true }, function (back) {
      if (chrome.runtime.lastError || !back) { reject(new Error((chrome.runtime.lastError && chrome.runtime.lastError.message) || "Sign-in was cancelled.")); return; }
      db.verifyCode("", back).then(function (r) { syncUsage(); profiles.pull().catch(function () {}); resolve(r); }, reject);
    });
  });
};

chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
  if (!msg) return;
  if (msg.type === "virtue-usage") { addUsage(msg.seconds).then(function () { reply({ ok: true }); }, function () { reply({ ok: false }); }); return true; }
  if (msg.type === "virtue-entitlement") {
    profiles.pullIfStale();   // pages ask every minute: a cheap moment to pick up profile changes
    entitlement(!!msg.fresh).then(function (e) { reply(e); }, function () { reply(null); });
    return true;
  }
});

// ---- filter profiles: named settings saved to the account; this browser follows one of them
var profiles = VirtueProfiles.create({
  db: db, core: VirtueCore, store: storage,
  getSettings: function () {
    return chrome.storage.sync.get("settings").then(function (r) {
      var s = Object.assign({}, VirtueCore.DEFAULT_SETTINGS, (r && r.settings) || {});
      s.categories = Object.assign({}, VirtueCore.DEFAULT_SETTINGS.categories, ((r && r.settings) || {}).categories || {});
      return s;
    });
  },
  setSettings: function (s) { return chrome.storage.sync.set({ settings: s }); }
});
chrome.storage.onChanged.addListener(function (ch, area) {
  if (area === "sync" && ch.settings && ch.settings.newValue) profiles.onLocalChange(ch.settings.newValue).catch(function () {});
});
chrome.runtime.onStartup.addListener(function () { profiles.pull().catch(function () {}); });
// (named profileX so they don't replace db.profiles / db.deleteProfile, which the sync itself uses)
db.profileList = function () { return profiles.pull(); };
db.profileUse = function (id) { return profiles.use(id); };
db.profileCreate = function (name, opts) { return profiles.create(name, opts); };
db.profileRename = function (id, name) { return profiles.rename(id, name); };
db.profileDelete = function (id) { return profiles.remove(id); };
db.profileDefault = function (id) { return profiles.makeDefault(id); };

// ---- sharing what Virtue finds (only with the viewer's consent, checked here too)
// Sends each find once: remembers what was already sent per video/title.
var SENT_KEY = "virtue.sent", STATS_KEY = "virtue.shareStats";
function findKey(s) { return s.action + ":" + s.category + ":" + Math.round(s.start * 10); }
async function share(service, id, title, segments) {
  var st = (await chrome.storage.sync.get("settings")).settings || {};
  if (!st.shareFindings || !st.shareConsentAt) return { shared: 0, reason: "no-consent" };
  if (!db.configured || !(await db.signedIn())) return { shared: 0, reason: "signed-out" };
  var all = (await storage.get(SENT_KEY)) || {};
  var k = service + ":" + id, isNewTitle = !all[k], sent = new Set(all[k] || []);
  var fresh = (segments || []).filter(function (s) { return !sent.has(findKey(s)); }).slice(0, 2000);
  if (!fresh.length) return { shared: 0, reason: "already-sent" };
  var res = await db.submit(service, id, title || {}, fresh);
  fresh.forEach(function (s) { sent.add(findKey(s)); });
  all[k] = Array.from(sent);
  var keys = Object.keys(all);
  if (keys.length > 3000) keys.slice(0, keys.length - 3000).forEach(function (old) { delete all[old]; });
  await storage.set(SENT_KEY, all);
  var stats = (await storage.get(STATS_KEY)) || { finds: 0, titles: 0 };
  stats.finds += (res && res.submitted) || 0;
  if (isNewTitle) stats.titles++;
  stats.last = new Date().toISOString();
  await storage.set(STATS_KEY, stats);
  return { shared: (res && res.submitted) || 0, duplicates: (res && res.duplicates) || 0 };
}
db.share = share;
db.shareStats = async function () { return (await storage.get(STATS_KEY)) || { finds: 0, titles: 0 }; };

chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
  if (!msg || msg.type !== "db") return;
  if (OPS.indexOf(msg.op) < 0) { reply({ ok: false, error: "unknown operation" }); return; }
  var args = msg.args || [];

  if (msg.op === "lookup" && !db.configured) { reply({ ok: true, res: null, offline: true }); return; }
  var ck = msg.op === "lookup" ? args.join("|") : null;
  if (ck && !msg.fresh && cache.has(ck) && Date.now() - cache.get(ck).at < CACHE_MS) {
    reply({ ok: true, res: cache.get(ck).res });
    return;
  }
  // Anything that changes data, or who you are, clears cached lookups.
  if (["submit", "share", "review", "vote", "verifyCode", "signOut"].indexOf(msg.op) >= 0) cache.clear();
  if (["verifyCode", "signOut", "googleSignIn"].indexOf(msg.op) >= 0) storage.set(PLAN_KEY, null);

  var after = msg.op === "verifyCode" ? function () { return profiles.pull().catch(function () {}); }
    : msg.op === "signOut" ? function () { return profiles.signedOut(); } : null;
  db[msg.op].apply(db, args).then(async function (res) {
    if (after) await after();
    if (ck) cache.set(ck, { at: Date.now(), res: res });
    reply({ ok: true, res: res });
  }).catch(function (e) {
    reply({ ok: false, error: e.message || String(e) });
  });
  return true;   // reply comes later
});
