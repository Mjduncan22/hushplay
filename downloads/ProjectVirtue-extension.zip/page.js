/*
 * Project Virtue - page hook (runs inside YouTube's page)
 * Finds the caption tracks for the current video and loads them in full,
 * then hands them to content.js. Only reads captions; never touches video data.
 *
 * How caption loading works on YouTube (checked Oct 2026):
 *  - A caption track's plain URL now returns an empty response. YouTube wants
 *    a token ("pot") that is tied to the specific video.
 *  - The player adds that token itself when it requests captions. We watch
 *    its requests, and with the token from one request we can load every
 *    caption track of that same video (auto-captions + uploader captions).
 *  - The player only requests captions while CC is on. If CC is off, we
 *    switch it on for an instant, catch the request, and switch it back off.
 */
(function () {
  "use strict";
  var TT = "/api/timedtext";
  var tokenUrlFor = {};            // videoId -> latest caption URL the player used (has its token)
  var responsesFor = {};           // videoId -> [{url, text}] caption responses the player got
  var origFetch = window.fetch;
  var currentId = null, loadingId = null;
  var lang = "en";

  function post(msg) {
    msg.source = "virtue-page";
    window.postMessage(msg, "*");
  }

  // ---- watch the player's own caption requests
  function noteTimedtext(url, text) {
    try {
      var u = new URL(url, location.origin);
      var v = u.searchParams.get("v");
      if (!v) return;
      if (u.searchParams.has("pot")) tokenUrlFor[v] = u.toString();
      if (text && text.charAt(0) === "{") {
        (responsesFor[v] = responsesFor[v] || []).push({ url: u, text: text });
        if (responsesFor[v].length > 6) responsesFor[v].shift();
      }
    } catch (e) {}
  }

  var origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    try {
      var s = url && url.toString ? url.toString() : "";
      if (s.indexOf(TT) >= 0) {
        noteTimedtext(s, null);                          // token is usable right away
        var xhr = this;
        xhr.addEventListener("load", function () {
          try {
            var t = (xhr.responseType === "" || xhr.responseType === "text") ? xhr.responseText : null;
            if (t) noteTimedtext(s, t);
          } catch (e) {}
        });
      }
    } catch (e) {}
    return origOpen.apply(this, arguments);
  };

  window.fetch = function (input) {
    var p = origFetch.apply(this, arguments);
    try {
      var url = typeof input === "string" ? input : (input && input.url);
      if (url && url.indexOf(TT) >= 0) {
        noteTimedtext(url, null);
        p.then(function (res) { res.clone().text().then(function (t) { noteTimedtext(url, t); }); })
          .catch(function () {});
      }
    } catch (e) {}
    return p;
  };

  // ---- helpers
  function videoIdFromUrl() {
    var m = location.pathname.match(/^\/(?:shorts|embed|live)\/([\w-]{11})/);
    if (m) return m[1];
    return new URLSearchParams(location.search).get("v");
  }

  function player() { return document.getElementById("movie_player"); }

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function getPlayerResponse(id) {
    var p = player();
    try {
      var pr = p && p.getPlayerResponse && p.getPlayerResponse();
      if (pr && pr.videoDetails && pr.videoDetails.videoId === id) return pr;
    } catch (e) {}
    var init = window.ytInitialPlayerResponse;
    if (init && init.videoDetails && init.videoDetails.videoId === id) return init;
    return null;
  }

  function langMatches(t) { return (t.languageCode || "").toLowerCase().indexOf(lang) === 0; }

  function pickTracks(pr) {
    var list = (pr.captions && pr.captions.playerCaptionsTracklistRenderer &&
      pr.captions.playerCaptionsTracklistRenderer.captionTracks) || [];
    var asr = list.filter(function (t) { return t.kind === "asr" && langMatches(t); })[0];
    var manual = list.filter(function (t) { return t.kind !== "asr" && langMatches(t); })[0];
    var out = [];
    if (asr) out.push({ kind: "asr", track: asr });
    if (manual) out.push({ kind: "manual", track: manual });
    return { picked: out, available: list.length };
  }

  // Params that say WHICH track a URL is for. Everything else (tokens, client info) can be borrowed.
  var IDENTITY = { v: 1, lang: 1, kind: 1, name: 1, tlang: 1, fmt: 1, variant: 1 };

  function buildUrl(track, tokenUrl) {
    var u = new URL(track.baseUrl, location.origin);
    if (tokenUrl) {
      new URL(tokenUrl).searchParams.forEach(function (val, key) {
        if (!IDENTITY[key] && !u.searchParams.has(key)) u.searchParams.set(key, val);
      });
    }
    u.searchParams.set("fmt", "json3");
    return u.toString();
  }

  async function tryFetch(url) {
    try {
      var r = await origFetch(url, { credentials: "include" });
      if (!r.ok) return null;
      var t = await r.text();
      if (!t || t.charAt(0) !== "{") return null;
      var j = JSON.parse(t);
      return j && j.events ? j : null;
    } catch (e) { return null; }
  }

  function adShowing() {
    var p = player();
    return !!(p && p.classList.contains("ad-showing"));
  }

  // Get the player to request captions for this video so we learn its token.
  async function getToken(id) {
    if (tokenUrlFor[id]) return tokenUrlFor[id];
    // CC already on: the player will request on its own shortly.
    for (var i = 0; i < 15 && !tokenUrlFor[id]; i++) await sleep(100);
    if (tokenUrlFor[id]) return tokenUrlFor[id];

    for (var attempt = 0; attempt < 4 && !tokenUrlFor[id]; attempt++) {
      // Wait out pre-roll ads (any length); the player won't load the video's captions during one.
      while (adShowing() && videoIdFromUrl() === id && loadingId === id) await sleep(250);
      if (videoIdFromUrl() !== id || loadingId !== id) return null;
      if (tokenUrlFor[id]) break;   // CC was on: the player loaded captions as the ad ended
      var p = player();
      if (!p || !p.toggleSubtitlesOn || !p.isSubtitlesOn) return null;
      var wasOn = false;
      try { wasOn = p.isSubtitlesOn(); } catch (e) {}
      try { p.toggleSubtitlesOn(); } catch (e) { return null; }
      for (var k = 0; k < 40 && !tokenUrlFor[id]; k++) await sleep(50);
      if (!wasOn) {
        try { if (p.isSubtitlesOn()) p.toggleSubtitles(); } catch (e) {}
      }
      if (!tokenUrlFor[id]) await sleep(1500);
    }
    return tokenUrlFor[id] || null;
  }

  async function loadTrack(id, entry, tokenUrl) {
    // the player may already have loaded this exact track
    var b = new URL(entry.track.baseUrl, location.origin);
    var seen = (responsesFor[id] || []).filter(function (r) {
      return r.url.searchParams.get("lang") === b.searchParams.get("lang") &&
        (r.url.searchParams.get("kind") || "") === (b.searchParams.get("kind") || "") &&
        !r.url.searchParams.get("tlang");
    }).pop();
    if (seen) { try { var j0 = JSON.parse(seen.text); if (j0.events) return j0; } catch (e) {} }
    return tryFetch(buildUrl(entry.track, tokenUrl));
  }

  async function loadVideo(id) {
    loadingId = id;
    post({ type: "status", videoId: id, state: "loading" });
    var pr = null;
    for (var i = 0; i < 50 && !pr; i++) {        // up to ~10 s for the player to be ready
      pr = getPlayerResponse(id);
      if (!pr) await sleep(200);
      if (loadingId !== id) return;
    }
    if (!pr) { post({ type: "tracks", videoId: id, tracks: [], error: "no-player" }); return; }

    var sel = pickTracks(pr);
    if (!sel.picked.length) {
      post({ type: "tracks", videoId: id, tracks: [], error: sel.available ? "no-language" : "no-captions" });
      return;
    }

    // Plain request first (works on some setups), otherwise borrow the player's token.
    var first = await tryFetch(buildUrl(sel.picked[0].track, tokenUrlFor[id]));
    var tokenUrl = tokenUrlFor[id] || null;
    if (!first) {
      tokenUrl = await getToken(id);
      if (loadingId !== id) return;
    }

    var tracks = [];
    for (var k = 0; k < sel.picked.length; k++) {
      var json = (k === 0 && first) ? first : await loadTrack(id, sel.picked[k], tokenUrl);
      if (loadingId !== id) return;
      if (json) tracks.push({ kind: sel.picked[k].kind, lang: sel.picked[k].track.languageCode, json: json });
    }
    post({ type: "tracks", videoId: id, tracks: tracks, error: tracks.length ? null : "fetch-failed" });
  }

  function check(force) {
    var id = videoIdFromUrl();
    if (!id) { if (currentId) { currentId = null; post({ type: "tracks", videoId: null, tracks: [] }); } return; }
    if (id !== currentId || force) { currentId = id; loadVideo(id); }
  }

  window.addEventListener("message", function (e) {
    if (e.source !== window || !e.data || e.data.source !== "virtue-content") return;
    if (e.data.type === "reload") {
      var newLang = e.data.language ? String(e.data.language).toLowerCase() : lang;
      var changed = newLang !== lang;
      lang = newLang;
      // content.js asks once at start-up; only redo the work if something changed
      check(changed);
    }
  });

  document.addEventListener("yt-navigate-finish", function () { check(false); });   // desktop site
  window.addEventListener("state-navigateend", function () { check(false); });     // mobile site
  setInterval(function () { check(false); }, 1000);
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", function () { check(false); });
  else check(false);
})();
