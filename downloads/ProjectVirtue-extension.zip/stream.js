/*
 * Project Virtue - movies & TV (Netflix, Prime Video, Disney+, Max, Hulu, ...)
 *
 * For whatever is playing it:
 *   - looks up the shared database for mute / skip segments (via background.js)
 *   - mutes swearing and skips scenes in the categories you've turned on
 *   - mutes swears found in the service's own subtitle file (when subtitles are on)
 *   - mutes while a swear is showing in on-screen captions (backup, line-level)
 *   - lets you tag as you watch:
 *       Alt+Shift+M  mute the last ~1.5 s (you just heard a swear)
 *       Alt+Shift+S  scene start / scene end (to skip)
 *       Alt+Shift+Z  undo your last tag
 *     Tags apply right away on this device; submit them from the popup.
 *
 * It only controls the player (mute, jump ahead). These services encrypt
 * their video, and nothing here reads or copies it.
 */
(function () {
  "use strict";
  var C = window.VirtueCore;
  var settings = Object.assign({}, C.DEFAULT_SETTINGS);
  var rules = C.compileRules(settings);

  // ------------------------------------------------------------------ settings
  function applySettings(s) {
    s = s || {};
    settings = Object.assign({}, C.DEFAULT_SETTINGS, s);
    settings.categories = Object.assign({}, C.DEFAULT_SETTINGS.categories, s.categories || {});
    rules = C.compileRules(settings);
    if (state && state.subs) buildSubtitleMutes();
    rebuild();
    if (state && state.subs) scheduleShare();   // e.g. sharing was just turned on
  }
  chrome.storage.sync.get("settings", function (r) { applySettings(r && r.settings); });
  chrome.storage.onChanged.addListener(function (ch, area) {
    if (area === "sync" && ch.settings) applySettings(ch.settings.newValue);
  });

  // ------------------------------------------------------------------ services
  function text(sel) {
    var el = sel && document.querySelector(sel);
    return el ? (el.innerText || el.textContent || "").trim() : "";
  }
  function lastSeg(p) { var a = p.split("/").filter(Boolean); return a[a.length - 1] || null; }

  var ADAPTERS = [
    { service: "netflix", host: /(^|\.)netflix\.com$/, seekViaPage: true,
      id: function () { var m = location.pathname.match(/\/watch\/(\d+)/); return m && m[1]; },
      title: function () { return text('[data-uia="video-title"] h4') || text('[data-uia="video-title"]'); },
      captions: ".player-timedtext-text-container, .player-timedtext" },
    { service: "prime", host: /(^|\.)(primevideo\.com|amazon\.(com|ca|co\.uk|de|fr|it|es|in|co\.jp|com\.au|com\.mx|com\.br))$/,
      id: function () {
        var m = location.pathname.match(/\/(?:detail|dp)\/([A-Z0-9]{10,})/i) ||
                location.search.match(/[?&]gti=([^&#]+)/);
        if (!m) return null;
        var ep = text(".atvwebplayersdk-subtitle-text");
        var se = ep && ep.match(/Season\s*(\d+)\D+?(\d+)/i);
        return m[1] + (se ? ":S" + se[1] + "E" + se[2] : "");
      },
      title: function () { return text(".atvwebplayersdk-title-text"); },
      episode: function () { return text(".atvwebplayersdk-subtitle-text"); },
      // Prime's video element clock isn't the show's clock; calibrate against the on-screen time.
      timeText: ".atvwebplayersdk-timeindicator-text",
      captions: ".atvwebplayersdk-captions-text" },
    { service: "disney", host: /(^|\.)disneyplus\.com$/,
      id: function () { var m = location.pathname.match(/\/(?:play|video)\/([\w-]+)/); return m && m[1]; },
      title: function () { return text(".title-field") || text('[data-testid="title-field"]'); },
      captions: ".dss-subtitle-renderer-line, .hive-subtitle-renderer-line" },
    { service: "max", host: /(^|\.)(max\.com|hbomax\.com)$/,
      id: function () { var m = location.pathname.match(/\/video\/watch\/([\w-]+)(?:\/([\w-]+))?/); return m && (m[2] || m[1]); },
      title: function () { return text('[data-testid="player-ux-asset-title"]'); },
      captions: '[data-testid="CueBoxContainer"], [class*="CaptionWindow"]' },
    { service: "hulu", host: /(^|\.)hulu\.com$/,
      id: function () { var m = location.pathname.match(/\/watch\/([\w-]+)/); return m && m[1]; },
      captions: '[class*="ClosedCaption"]' },
    { service: "peacock", host: /(^|\.)peacocktv\.com$/,
      id: function () { return /\/watch\//.test(location.pathname) ? lastSeg(location.pathname) : null; } },
    { service: "paramount", host: /(^|\.)paramountplus\.com$/,
      id: function () { return /\/(video|movies)\//.test(location.pathname) ? lastSeg(location.pathname) : null; } },
    { service: "appletv", host: /^tv\.apple\.com$/,
      id: function () { var m = location.pathname.match(/(umc\.cmc\.[a-z0-9]+)/i); return m && m[1]; } }
  ];
  var A = ADAPTERS.filter(function (a) { return a.host.test(location.hostname); })[0];
  if (!A) return;
  var GENERIC_CAPTIONS = '[class*="caption" i], [class*="subtitle" i], [class*="timedtext" i]';

  function video() {
    var best = null, area = 0;
    var vids = document.querySelectorAll("video");
    for (var i = 0; i < vids.length; i++) {
      var r = vids[i].getBoundingClientRect(), a = r.width * r.height;
      if (vids[i].readyState >= 1 && a > area) { best = vids[i]; area = a; }
    }
    return best;
  }

  // ------------------------------------------------------------------ clock
  // Service time = video.currentTime + offset. Most services: offset 0.
  // Prime: learn the offset from the moment the on-screen clock ticks over.
  var clock = { offset: A.timeText ? null : 0, lastText: null, samples: [], since: Date.now() };

  function parseClock(s) {
    var m = /(\d+:)?\d+:\d{2}/.exec(s || "");
    if (!m) return null;
    return m[0].split(":").reduce(function (acc, p) { return acc * 60 + (+p); }, 0);
  }

  function serviceTime(v) {
    if (A.timeText) {
      var shown = text(A.timeText);
      if (shown && shown !== clock.lastText && !v.paused) {
        var secs = parseClock(shown);
        if (clock.lastText !== null && secs !== null) {
          clock.samples.push(secs - v.currentTime);
          if (clock.samples.length > 7) clock.samples.shift();
          var sorted = clock.samples.slice().sort(function (a, b) { return a - b; });
          clock.offset = sorted[sorted.length >> 1];
        }
        clock.lastText = shown;
      }
      // No on-screen clock found for a while: assume the plain video clock.
      if (clock.offset === null && Date.now() - clock.since > 8000 && !document.querySelector(A.timeText)) clock.offset = 0;
    }
    return clock.offset === null ? null : v.currentTime + clock.offset;
  }

  // ------------------------------------------------------------------ data
  var state = blank(null);
  function blank(id) {
    return { id: id, phase: id ? "loading" : "no-title", error: null, db: null, local: [],
      mutes: [], skips: [], title: "", verify: C.verification(null, []), shareTimer: null, subs: { cues: {}, lines: 0, files: 0, base: null, intervals: [] } };
  }

  // ------------------------------------------------------------------ subtitle files
  // subs-page.js hands over each subtitle file the player downloads. Swears in it
  // become mutes placed inside their line (same timing method as YouTube captions).
  function addSubtitles(text) {
    if (!state.id || settings.useSubtitles === false) return;
    var p = C.parseSubtitles(text);
    if (!p || !p.cues.length) return;
    var sub = state.subs;
    // HLS players count from the stream's first timestamp, so shift by the smallest offset seen.
    if (sub.base === null || p.tsShift < sub.base) {
      if (sub.base !== null) {
        var d = sub.base - p.tsShift, moved = {};
        Object.keys(sub.cues).forEach(function (k) { var c = sub.cues[k]; c.start += d; c.end += d; moved[key(c)] = c; });
        sub.cues = moved;
      }
      sub.base = p.tsShift;
    }
    var added = 0;
    p.cues.forEach(function (c) {
      var cue = { start: c.start - sub.base, end: c.end - sub.base, text: c.text };
      var k = key(cue);
      if (!sub.cues[k]) { sub.cues[k] = cue; added++; }
    });
    sub.files++;
    if (!added) return;
    sub.lines = Object.keys(sub.cues).length;
    buildSubtitleMutes();
    rebuild();
    scheduleShare();
  }

  // With the viewer's consent only: share the swear timestamps found in the subtitle
  // file (times, category, censored word). Subtitles arrive in pieces while you watch,
  // so this waits for a quiet moment; background.js only sends finds it hasn't sent before.
  function scheduleShare() {
    if (!C.canShare(settings) || !state.id || !state.subs.lines) return;
    clearTimeout(state.shareTimer);
    var id = state.id;
    state.shareTimer = setTimeout(function () {
      if (state.id !== id) return;
      var cues = Object.keys(state.subs.cues).map(function (k) { return state.subs.cues[k]; })
        .sort(function (a, b) { return a.start - b.start; });
      var segs = C.shareableMutes([{ kind: "manual", json: C.cuesToTrack(cues) }], "subtitles");
      if (!segs.length) return;
      chrome.runtime.sendMessage({ type: "db", op: "share", args: [A.service, id, titleInfo(), segs] }, function (r) {
        if (chrome.runtime.lastError || state.id !== id) return;
        state.shared = r && r.ok ? r.res : { shared: 0, reason: r && r.error };
      });
    }, SHARE_WAIT_MS);
  }
  var SHARE_WAIT_MS = +(document.documentElement.getAttribute("data-virtue-share-wait") || 15000);   // tests shorten it
  function key(c) { return Math.round(c.start * 10) + "|" + c.text; }
  function buildSubtitleMutes() {
    var cues = Object.keys(state.subs.cues).map(function (k) { return state.subs.cues[k]; })
      .sort(function (a, b) { return a.start - b.start; });
    state.subs.intervals = cues.length ? C.buildIntervals([{ kind: "manual", json: C.cuesToTrack(cues) }], settings) : [];
  }
  window.addEventListener("message", function (e) {
    if (e.source !== window || !e.data || e.data.source !== "virtue-subs") return;
    if (e.data.page && e.data.page !== location.pathname) return;
    if (!state.id) { var id = A.id(); if (id) load(id); }   // file arrived before our first tick
    try { addSubtitles(String(e.data.text || "")); } catch (err) {}
  });

  function tagKey(id) { return "virtue.tags." + A.service + ":" + id; }

  function load(id) {
    state = blank(id);
    clock = { offset: A.timeText ? null : 0, lastText: null, samples: [], since: Date.now() };
    chrome.storage.local.get(tagKey(id), function (r) {
      if (state.id !== id) return;
      state.local = (r && r[tagKey(id)]) || [];
      rebuild();
    });
    window.postMessage({ source: "virtue-subs-req" }, "*");   // replay files already downloaded for this page
    if (!settings.useDatabase) { state.phase = "ready"; rebuild(); return; }
    chrome.runtime.sendMessage({ type: "db", op: "lookup", args: [A.service, id] }, function (resp) {
      if (state.id !== id) return;
      if (chrome.runtime.lastError || !resp) { state.phase = "error"; state.error = "no-connection"; rebuild(); return; }
      if (!resp.ok) { state.phase = "error"; state.error = resp.error; rebuild(); return; }
      state.db = resp.res;           // null = not in the database yet
      state.phase = resp.offline ? "offline" : "ready";
      rebuild();
      announce();
    });
  }

  function saveLocal() {
    var o = {};
    o[tagKey(state.id)] = state.local;
    chrome.storage.local.set(o);
  }

  function enabled(cat) {
    if (cat === "custom") return true;
    if (cat === "censored") return settings.categories.strong !== false;
    return settings.categories[cat] !== false;
  }

  // All segments that apply here: approved ones + your own pending + your new local tags.
  function allSegments() {
    var out = [];
    // Verified ones, plus unverified ones unless the viewer turned those off.
    C.usableSegments(state.db, settings).forEach(function (s) { out.push(s); });
    state.local.forEach(function (s, i) { out.push(Object.assign({ local: true, index: i, status: "new" }, s)); });
    return out.sort(function (a, b) { return a.start - b.start; });
  }

  function merge(list) {
    var out = [];
    list.sort(function (a, b) { return a.start - b.start; }).forEach(function (s) {
      var p = out[out.length - 1];
      if (p && s.start <= p.end + 0.05) { p.end = Math.max(p.end, s.end); if (p.cats.indexOf(s.category) < 0) p.cats.push(s.category); }
      else out.push({ start: s.start, end: s.end, cats: [s.category] });
    });
    return out;
  }

  function rebuild() {
    if (state.subs) state.verify = C.verification(state.db, C.usableSegments(state.db, settings));
    var segs = allSegments().filter(function (s) { return enabled(s.category); });
    var mutes = segs.filter(function (s) { return s.action === "mute"; });
    if (settings.useSubtitles !== false && state.subs) {
      state.subs.intervals.forEach(function (iv) {
        mutes.push({ start: iv.start, end: iv.end, category: iv.categories[0] || "strong", source: "subtitles" });
      });
    }
    state.mutes = merge(mutes);
    state.skips = merge(segs.filter(function (s) { return s.action === "skip"; }));
  }

  // ------------------------------------------------------------------ engine
  var weMuted = false, liveMuteUntil = 0, skipTry = null, covering = null;
  var LEAD = 0.015;

  function setMuted(v, want) {
    if (want && !v.muted) { v.muted = true; weMuted = true; }
    else if (!want && weMuted) { v.muted = false; weMuted = false; }
  }

  function seekTo(v, target, now) {
    if (A.seekViaPage) {
      var reqId = Math.random().toString(36).slice(2);
      window.postMessage({ source: "virtue-stream", type: "seek", t: target, id: reqId }, "*");
    } else {
      v.currentTime = v.currentTime + (target - now);
    }
  }

  function tick() {
    var id = A.id();
    if (id !== state.id) {
      covering = null; skipTry = null;
      if (id) load(id); else state = blank(null);
    }
    var v = video();
    if (!v || !id || !settings.enabled || locked) {
      if (v) setMuted(v, false);
      showCover(false);
      return;
    }
    var t = serviceTime(v);
    if (t === null) return;
    state.now = t;

    // Skips. If jumping doesn't work, cover the screen and mute until the scene is over.
    var si = C.findInterval(state.skips, t + 0.05);
    if (covering && (t >= covering.end || t < covering.start - 1)) covering = null;
    if (si >= 0 && !covering) {
      var iv = state.skips[si];
      if (!skipTry || skipTry.iv !== iv) skipTry = { iv: iv, tries: 0, at: 0 };
      if (Date.now() - skipTry.at > 700) {
        if (skipTry.tries < 3) {
          skipTry.tries++;
          skipTry.at = Date.now();
          seekTo(v, iv.end + 0.05, t);
          flash("Skipped " + label(iv.cats));
        } else {
          covering = iv;
        }
      }
    }
    if (si < 0) skipTry = null;
    showCover(!!covering);

    // Mutes (database / your tags), plus the live caption backup.
    var inMute = C.findInterval(state.mutes, t + LEAD * (v.playbackRate || 1)) >= 0;
    var live = Date.now() < liveMuteUntil;
    setMuted(v, inMute || live || !!covering || si >= 0);   // also silent while a skip is happening
    showMuting((inMute || live) && !covering);
  }
  setInterval(tick, 25);

  // ------------------------------------------------------------------ free trial
  // Counts time spent watching with Virtue filtering; filtering only stops when the
  // paywall is on, the free hours are used up and there's no subscription.
  var locked = false, ent = null, usageSec = 0, lockedNoticeFor = null;
  function checkEntitlement() {
    try {
      chrome.runtime.sendMessage({ type: "virtue-entitlement" }, function (e) {
        if (chrome.runtime.lastError || !e) return;
        ent = e; locked = !e.allowed;
      });
    } catch (err) {}
  }
  setInterval(checkEntitlement, 60000);
  setTimeout(checkEntitlement, 500);
  setInterval(function () {
    var v = video();
    var playing = v && !v.paused && state.id;
    if (playing && settings.enabled && !locked) usageSec++;
    if (usageSec >= 30) {
      try { chrome.runtime.sendMessage({ type: "virtue-usage", seconds: usageSec }, function () { void chrome.runtime.lastError; }); } catch (err) {}
      usageSec = 0;
    }
    if (locked && playing && lockedNoticeFor !== state.id) {
      lockedNoticeFor = state.id;
      flash(C.trialLine(ent) || "Your free trial is over. Subscribe to keep filtering.", 9000, true);
    }
  }, 1000);
  window.addEventListener("pagehide", function () { var v = video(); if (v) setMuted(v, false); });

  function label(cats) {
    var names = { nudity: "nudity", sexual: "sexual content", violence: "violence", other: "scene" };
    return cats.map(function (c) { return names[c] || c; }).join(" / ");
  }

  // Backup: mute while a line with a swear is showing in the on-screen captions.
  var capQueued = false;
  new MutationObserver(function () {
    if (capQueued) return;
    capQueued = true;
    requestAnimationFrame(function () {
      capQueued = false;
      if (!settings.enabled) return;
      var nodes = document.querySelectorAll(A.captions || GENERIC_CAPTIONS);
      for (var i = 0; i < nodes.length; i++) {
        var s = (nodes[i].innerText || nodes[i].textContent || "").trim();
        if (s && s.length < 400 && C.censorText(s, rules).hit) { liveMuteUntil = Date.now() + 700; break; }
      }
    });
  }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  // ------------------------------------------------------------------ tagging hotkeys
  var sceneStart = null;
  window.addEventListener("keydown", function (e) {
    if (!e.altKey || !e.shiftKey || e.ctrlKey || e.metaKey) return;
    var k = (e.code || "").replace("Key", "");
    if (["M", "S", "Z"].indexOf(k) < 0) return;
    var v = video(), t = v && serviceTime(v);
    if (!state.id || t === null || t === undefined) { flash("Start the video first"); return; }
    e.preventDefault();
    e.stopPropagation();
    if (k === "M") {
      addTag({ start: Math.max(0, t - 1.5), end: t + 0.3, action: "mute", category: "strong", label: "marked" });
      flash("Mute tag added at " + C.fmtTime(t));
    } else if (k === "S") {
      if (sceneStart === null) { sceneStart = t; flash("Scene start " + C.fmtTime(t) + " — press again at the end"); }
      else {
        var s = Math.min(sceneStart, t), en = Math.max(sceneStart, t);
        sceneStart = null;
        if (en - s < 0.5) { flash("Scene too short — cancelled"); return; }
        addTag({ start: Math.max(0, s - 0.5), end: en + 0.5, action: "skip", category: settings.sceneCategory || "nudity", label: "scene" });
        flash("Scene tagged " + C.fmtTime(s) + "–" + C.fmtTime(en));
      }
    } else if (k === "Z") {
      if (sceneStart !== null) { sceneStart = null; flash("Scene mark cancelled"); return; }
      if (!state.local.length) { flash("Nothing to undo"); return; }
      state.local.pop();
      saveLocal(); rebuild();
      flash("Last tag removed");
    }
  }, true);

  function addTag(tag) {
    tag.start = Math.round(tag.start * 100) / 100;
    tag.end = Math.round(tag.end * 100) / 100;
    tag.source = "manual";
    tag.created = Date.now();
    state.local.push(tag);
    saveLocal();
    rebuild();
  }

  // ------------------------------------------------------------------ overlay (works in fullscreen)
  var badge = null, cover = null, flashTimer = null;
  function host() { return document.fullscreenElement || document.body; }
  function ensure(el, cls) {
    if (!el) { el = document.createElement("div"); el.className = cls; }
    var h = host();
    if (h && el.parentNode !== h) h.appendChild(el);
    return el;
  }
  function showMuting(on) {
    if (!settings.showIndicator) on = false;
    if (!on && !badge) return;
    badge = ensure(badge, "virtue-stream-badge");
    badge.classList.toggle("muting", on);
    if (on) badge.textContent = "Muted";
    else if (!badge.classList.contains("toast")) badge.textContent = "";
  }
  function flash(msg, ms, warn) {
    badge = ensure(badge, "virtue-stream-badge");
    badge.textContent = msg;
    badge.classList.add("toast");
    badge.classList.toggle("warn", !!warn);
    clearTimeout(flashTimer);
    flashTimer = setTimeout(function () { badge.classList.remove("toast", "warn"); if (!badge.classList.contains("muting")) badge.textContent = ""; }, ms || 2500);
  }
  function showCover(on) {
    if (!on && !cover) return;
    cover = ensure(cover, "virtue-stream-cover");
    cover.textContent = "Skipping scene…";
    cover.classList.toggle("on", on);
  }
  document.addEventListener("fullscreenchange", function () {
    if (badge) ensure(badge, "virtue-stream-badge");
    if (cover) ensure(cover, "virtue-stream-cover");
  });
  function announce() {
    if (!settings.showIndicator || locked) return;
    var n = allSegments().filter(function (s) { return enabled(s.category); }).length;
    var v = state.verify.state, unverified = v === "unverified" || v === "partial";
    if (state.phase === "ready") flash(n ? "Virtue on · " + n + " filter" + (n === 1 ? "" : "s") + " for this title" +
      (unverified ? " · timestamps not verified" : "")
      : "Virtue on · no filters for this title yet", unverified ? 7000 : 2500, unverified);
  }

  // ------------------------------------------------------------------ popup
  function titleInfo() {
    var name = (A.title && A.title()) || document.title.replace(/\s*[|\-–]\s*(Netflix|Prime Video|Disney\+|Max|HBO Max|Hulu|Peacock|Paramount\+|Apple TV\+?).*$/i, "").trim();
    var ep = A.episode ? A.episode() : "";
    var se = ep && ep.match(/Season\s*(\d+)\D+?(\d+)/i);
    return { name: name, kind: se ? "episode" : "movie", season: se ? +se[1] : null, episode: se ? +se[2] : null };
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
    if (msg.type === "status") {
      var segs = allSegments();
      reply({
        kind: "stream", service: A.service, serviceId: state.id, phase: state.id ? state.phase : "no-title",
        error: state.error, inDatabase: !!state.db, title: state.db ? state.db.title : null,
        guess: titleInfo(), now: state.now || 0, clockReady: clock.offset !== null,
        segments: segs, localCount: state.local.length, settingsEnabled: settings.enabled,
        locked: locked, entitlement: ent,
        verify: state.verify, verifyMessage: C.verificationMessage(state.verify), shared: state.shared || null,
        subtitles: { files: state.subs.files, lines: state.subs.lines, mutes: settings.useSubtitles === false ? 0 : state.subs.intervals.length }
      });
    } else if (msg.type === "seek") {
      var v = video(), t = v && serviceTime(v);
      if (v && t !== null) seekTo(v, Math.max(0, msg.t), t);
      reply({ ok: true });
    } else if (msg.type === "tag-update") {
      var tag = state.local[msg.index];
      if (tag) {
        if (msg.remove) state.local.splice(msg.index, 1);
        else Object.assign(tag, msg.patch || {});
        saveLocal(); rebuild();
      }
      reply({ ok: true });
    } else if (msg.type === "submit") {
      var info = Object.assign(titleInfo(), msg.title || {});
      var payload = state.local.map(function (s) {
        return { start: s.start, end: s.end, action: s.action, category: s.category, label: s.label, source: "manual" };
      });
      var id = state.id;
      chrome.runtime.sendMessage({ type: "db", op: "submit", args: [A.service, id, info, payload] }, function (resp) {
        if (resp && resp.ok) {
          state.local = [];
          saveLocal();
          chrome.runtime.sendMessage({ type: "db", op: "lookup", args: [A.service, id], fresh: true }, function (r2) {
            if (r2 && r2.ok && state.id === id) { state.db = r2.res; state.phase = "ready"; rebuild(); }
            reply(resp);
          });
        } else {
          reply(resp || { ok: false, error: "No response" });
        }
      });
    } else if (msg.type === "reload") {
      if (state.id) load(state.id);
      reply({ ok: true });
    }
    return true;
  });
})();
