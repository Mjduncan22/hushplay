/*
 * HushPlay - subtitle file watcher (runs inside streaming service pages).
 * When the player downloads a subtitle file (TTML or WebVTT) because you turned
 * subtitles on, pass its text to stream.js so swears can be muted ahead of time.
 * Only subtitle text is looked at; video and audio are never touched.
 */
(function () {
  "use strict";
  if (window.__virtueSubsHooked) return;
  window.__virtueSubsHooked = true;

  var MAX = 8 * 1024 * 1024;
  var recent = [];            // last few files, re-sent if stream.js starts late
  var HINT = /\.(vtt|webvtt|ttml|dfxp|xml)(\?|$)|subtitle|caption|timedtext|texttrack|\/tt\//i;
  var TEXTUAL = /text\/|xml|ttml|vtt/i;
  var BINARYISH = /video|audio|image|font|javascript|json|html|mp4|mpegurl|dash\+xml/i;

  function looksLikeSubs(t) {
    if (typeof t !== "string" || !t || t.length > MAX) return false;
    var h = t.slice(0, 600);
    return /^﻿?WEBVTT/.test(h) || /<(\w+:)?tt[\s>]/.test(h);
  }

  function post(text, url) {
    var msg = { source: "virtue-subs", text: text, url: String(url || "").slice(0, 300), page: location.pathname };
    recent.push(msg);
    if (recent.length > 12) recent.shift();
    window.postMessage(msg, "*");
  }

  function worthReading(url, contentType) {
    contentType = contentType || "";
    if (BINARYISH.test(contentType) && !/vtt|ttml/.test(contentType)) return false;
    return TEXTUAL.test(contentType) || HINT.test(url || "") || /octet-stream/.test(contentType);
  }

  var origFetch = window.fetch;
  window.fetch = function () {
    var p = origFetch.apply(this, arguments);
    p.then(function (res) {
      try {
        var ct = res.headers.get("content-type") || "";
        var len = +(res.headers.get("content-length") || 0);
        if (len > MAX || !worthReading(res.url, ct)) return;
        res.clone().text().then(function (t) { if (looksLikeSubs(t)) post(t, res.url); }).catch(function () {});
      } catch (e) {}
    }).catch(function () {});
    return p;
  };

  var origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    var xhr = this, u = url && url.toString ? url.toString() : "";
    xhr.addEventListener("load", function () {
      try {
        var ct = xhr.getResponseHeader("content-type") || "";
        if (!worthReading(u, ct)) return;
        var t = null;
        if (xhr.responseType === "" || xhr.responseType === "text") t = xhr.responseText;
        else if (xhr.responseType === "arraybuffer" && xhr.response && xhr.response.byteLength < MAX) {
          t = new TextDecoder("utf-8").decode(xhr.response);
        }
        if (looksLikeSubs(t)) post(t, u);
      } catch (e) {}
    });
    return origOpen.apply(this, arguments);
  };

  window.addEventListener("message", function (e) {
    if (e.source === window && e.data && e.data.source === "virtue-subs-req") {
      recent.forEach(function (m) { if (m.page === location.pathname) window.postMessage(m, "*"); });
    }
  });
})();
