/*
 * HushPlay - Netflix page helper (runs inside Netflix's page).
 * Netflix shows an error if a page moves its video directly, so skips go
 * through Netflix's own player controls. stream.js asks with:
 *   window.postMessage({ source: "virtue-stream", type: "seek", t: seconds, id }, "*")
 */
(function () {
  "use strict";
  function player() {
    var api = window.netflix && window.netflix.appContext && window.netflix.appContext.state &&
      window.netflix.appContext.state.playerApp && window.netflix.appContext.state.playerApp.getAPI();
    var vp = api && api.videoPlayer;
    if (!vp) return null;
    var ids = vp.getAllPlayerSessionIds() || [];
    var sid = ids.filter(function (s) { return s.indexOf("watch") >= 0; })[0] || ids[0];
    return sid ? vp.getVideoPlayerBySessionId(sid) : null;
  }

  window.addEventListener("message", function (e) {
    if (e.source !== window || !e.data || e.data.source !== "virtue-stream" || e.data.type !== "seek") return;
    var ok = false;
    try {
      var p = player();
      if (p) { p.seek(Math.round(e.data.t * 1000)); ok = true; }
    } catch (err) { ok = false; }
    window.postMessage({ source: "virtue-stream-page", type: "seek-result", id: e.data.id, ok: ok }, "*");
  });
})();
