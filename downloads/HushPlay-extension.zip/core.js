/*
 * HushPlay - caption core
 * Turns YouTube caption tracks (json3 format) into a list of mute intervals.
 * No DOM access here, so the same file runs in the extension and in Node tests.
 */
(function (root) {
  "use strict";

  // Same word lists as tagger/filters.json. Each pattern must match a WHOLE word.
  var CATEGORIES = {
    strong: ["\\w*fuck\\w*", "\\w*fuk\\w*", "\\w*shit\\w*", "cunts?", "cocksuck\\w*", "twats?", "motherf\\w*"],
    mild: ["damn\\w*", "dammit", "hell", "ass(es|hole|holes)?",
      "(dumb|jack|smart|bad|kick|kiss|hard|lard|fat|wise)ass(es)?", "arse(hole)?s?", "bitch\\w*",
      "bastards?", "crap(py)?", "piss(ed|es|ing)?", "dicks?", "dickhead\\w*", "pricks?", "douche\\w*",
      "slut\\w*", "whores?", "bollocks", "bugger\\w*"],
    blasphemy: ["god damn\\w*", "god dammit", "goddam\\w*", "jesus christ", "jesus", "christ",
      "oh my god", "my god", "oh god", "for god's sake", "for gods sake", "omg"],
    slurs: ["nigg\\w*", "fag(s|got|gots)?", "retard(s|ed)?", "spics?", "kikes?", "chinks?", "dykes?", "trann(y|ies)"]
  };

  var DEFAULT_SETTINGS = {
    enabled: true,
    categories: { strong: true, mild: true, blasphemy: true, slurs: true,
      nudity: true, sexual: true, violence: false, other: true },   // last four: scene skips (movies/TV)
    sceneCategory: "nudity",  // what a scene you mark with Alt+Shift+S is filed under
    soundCues: "ask",         // scenes guessed from subtitle sound cues: "ask" (offer a Skip button), "auto" (skip), "off"
    violenceLevel: 2,         // skip violence at this level and up: 1 mild, 2 moderate, 3 graphic only
    useDatabase: true,        // look up shared mute/skip lists for movies & TV
    useSubtitles: true,       // movies & TV: mute swears found in the service's own subtitle file
    useUnverified: true,      // also use database timestamps a reviewer hasn't checked yet (shown as "not verified")
    shareFindings: false,     // send swear timestamps HushPlay finds to the shared database (needs consent + sign-in)
    shareConsentAt: null,     // when the viewer agreed to sharing (ISO time); sharing never happens without it
    custom: "",               // comma-separated extra words/phrases
    allow: "",                // comma-separated words to never mute
    padBefore: 0.2,           // seconds muted before a word
    padAfter: 0.3,            // seconds muted after a word
    mergeGap: 0.5,            // join mutes closer than this
    uploaderMode: "word",     // "word" = estimate the word inside the line, "line" = mute the whole line
    censorCaptions: true,     // star out swears in on-screen captions
    showIndicator: true,      // small "muted" badge on the player
    showBubble: true,         // round "H" button on the video with the list of mutes and skips
    bubbleOpacity: 1,         // how see-through that button is when not in use (0.2 - 1)
    language: "en"
  };

  // ------------------------------------------------------------- text helpers

  function normalize(w) {
    w = String(w).toLowerCase().replace(/’/g, "'");
    w = w.replace(/[^a-z0-9'*_]+/g, "");
    return w.replace(/^'+|'+$/g, "");
  }

  function isCensoredToken(n) {
    // YouTube auto-captions write swears as "[ __ ]"; some captions use "f***".
    return /^_{2,}$/.test(n) || (/\*/.test(n) && /[a-z]/.test(n));
  }

  function censor(word) {
    var w = String(word).trim().replace(/^[.,!?;:"()\[\]]+|[.,!?;:"()\[\]]+$/g, "");
    if (/^_+$/.test(w) || /\*/.test(w)) return w;   // already censored - leave it alone
    if (w.length <= 1) return w;
    return w[0] + w.slice(1).replace(/[A-Za-z0-9]/g, "*");
  }

  function escapeRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

  function splitList(s) {
    return String(s || "").split(/[,\n]/).map(function (x) { return x.trim().toLowerCase(); })
      .filter(Boolean);
  }

  // ------------------------------------------------------------- rules

  function compileRules(settings) {
    settings = settings || DEFAULT_SETTINGS;
    var rules = [];
    var cats = settings.categories || {};
    Object.keys(CATEGORIES).forEach(function (cat) {
      if (cats[cat] === false) return;
      CATEGORIES[cat].forEach(function (p) { rules.push(makeRule(cat, p)); });
    });
    splitList(settings.custom).forEach(function (w) {
      // custom words: literal, allow simple plurals/suffixes with a trailing *
      var p = w.split(/\s+/).map(function (t) {
        return t.slice(-1) === "*" ? escapeRe(t.slice(0, -1)) + "\\w*" : escapeRe(t);
      }).join(" ");
      rules.push(makeRule("custom", p));
    });
    rules.sort(function (a, b) { return b.tokens.length - a.tokens.length; });
    rules.allow = {};
    splitList(settings.allow).forEach(function (w) { rules.allow[normalize(w)] = true; });
    return rules;
  }

  function makeRule(category, pattern) {
    return {
      category: category,
      pattern: pattern,
      tokens: pattern.toLowerCase().split(/\s+/).map(function (t) { return new RegExp("^(?:" + t + ")$"); })
    };
  }

  // Find matches in a list of {norm, ...} tokens. Returns [{first, last, category}].
  function matchTokens(tokens, rules) {
    var out = [];
    var i = 0;
    while (i < tokens.length) {
      var n = tokens[i].norm;
      if (isCensoredToken(n)) { out.push({ first: i, last: i, category: "censored" }); i++; continue; }
      var hit = null;
      for (var r = 0; r < rules.length; r++) {
        var rule = rules[r], ok = i + rule.tokens.length <= tokens.length;
        for (var k = 0; ok && k < rule.tokens.length; k++) {
          var tn = tokens[i + k].norm;
          if (rules.allow && rules.allow[tn]) ok = false;
          else ok = rule.tokens[k].test(tn);
        }
        if (ok) { hit = rule; break; }
      }
      if (hit) {
        out.push({ first: i, last: i + hit.tokens.length - 1, category: hit.category });
        i += hit.tokens.length;
      } else {
        i++;
      }
    }
    return out;
  }

  // ------------------------------------------------------------- caption parsing

  function tokenize(text) {
    // -> [{raw, norm, cs, ce}] with character offsets; drops punctuation-only bits
    var out = [], re = /\S+/g, m;
    while ((m = re.exec(text))) {
      var norm = normalize(m[0]);
      if (!norm.replace(/[*']/g, "") && !/_{2,}/.test(norm)) continue;
      out.push({ raw: m[0], norm: norm, cs: m.index, ce: m.index + m[0].length });
    }
    return out;
  }

  function isWordTimed(json) {
    var ev = (json && json.events) || [];
    for (var i = 0; i < ev.length; i++) {
      var segs = ev[i].segs || [];
      for (var j = 0; j < segs.length; j++) if (segs[j].tOffsetMs !== undefined) return true;
    }
    return false;
  }

  // Auto-captions: every seg is a word with its own start time.
  function wordsFromTimed(json) {
    var segs = [];
    (json.events || []).forEach(function (ev) {
      if (!ev.segs || ev.tStartMs === undefined) return;
      ev.segs.forEach(function (s) {
        if (!s.utf8 || !s.utf8.trim()) return;
        segs.push({ text: s.utf8, start: (ev.tStartMs + (s.tOffsetMs || 0)) / 1000,
          evEnd: (ev.tStartMs + (ev.dDurationMs || 0)) / 1000 });
      });
    });
    segs.sort(function (a, b) { return a.start - b.start; });
    var words = [];
    for (var i = 0; i < segs.length; i++) {
      var s = segs[i], next = null;
      for (var j = i + 1; j < segs.length; j++) if (segs[j].start > s.start) { next = segs[j].start; break; }
      var maxLen = 0.25 + 0.08 * s.text.trim().length;           // a word rarely lasts longer than this
      var end = Math.min(next !== null ? next : s.evEnd, s.start + Math.max(0.4, maxLen));
      if (end <= s.start) end = s.start + 0.3;
      tokenize(s.text).forEach(function (t) {
        words.push({ raw: t.raw, norm: t.norm, start: s.start, end: end, estimated: false });
      });
    }
    return words;
  }

  // Uploader captions: one line with a start and duration. Word times are estimated.
  function wordsFromLines(json) {
    var words = [];
    (json.events || []).forEach(function (ev) {
      if (!ev.segs || ev.tStartMs === undefined) return;
      var text = ev.segs.map(function (s) { return s.utf8 || ""; }).join("").replace(/\n/g, " ");
      if (!text.trim()) return;
      var t0 = ev.tStartMs / 1000, d = (ev.dDurationMs || 2000) / 1000, L = text.length;
      tokenize(text).forEach(function (t) {
        words.push({ raw: t.raw, norm: t.norm, start: t0 + d * t.cs / L, end: t0 + d * t.ce / L,
          estimated: true, lineStart: t0, lineEnd: t0 + d });
      });
    });
    return words;
  }

  function parseTrack(json) {
    if (typeof json === "string") json = JSON.parse(json);
    return isWordTimed(json) ? wordsFromTimed(json) : wordsFromLines(json);
  }

  // ------------------------------------------------------------- intervals

  function hitsFor(words, rules, source) {
    return matchTokens(words, rules).map(function (h) {
      var span = words.slice(h.first, h.last + 1);
      return {
        start: span[0].start, end: span[span.length - 1].end,
        estimated: span[0].estimated,
        lineStart: span[0].lineStart, lineEnd: span[span.length - 1].lineEnd,
        category: h.category, source: source,
        text: span.map(function (w) { return /^_+$/.test(w.norm) ? "[__]" : censor(w.raw); }).join(" ")
      };
    });
  }

  /*
   * tracks: [{kind: "asr"|"manual", json}]
   * Auto-captions (word timed) are trusted for timing. Uploader captions add
   * anything the auto-captions missed, using an estimated window.
   */
  function buildIntervals(tracks, settings) {
    settings = Object.assign({}, DEFAULT_SETTINGS, settings || {});
    var rules = compileRules(settings);
    var precise = [], estimated = [];
    (tracks || []).forEach(function (tr) {
      var words;
      try { words = parseTrack(tr.json); } catch (e) { return; }
      hitsFor(words, rules, tr.kind).forEach(function (h) {
        (h.estimated ? estimated : precise).push(h);
      });
    });

    var pb = +settings.padBefore, pa = +settings.padAfter, raw = [];
    precise.forEach(function (h) {
      raw.push({ start: h.start - pb, end: h.end + pa, text: h.text, category: h.category, source: h.source });
    });
    estimated.forEach(function (h) {
      var covered = precise.some(function (p) { return p.end > h.lineStart - 1 && p.start < h.lineEnd + 1; });
      if (covered) return;
      var s, e;
      if (settings.uploaderMode === "line") {
        s = h.lineStart - 0.1; e = h.lineEnd;
      } else {
        var lineLen = h.lineEnd - h.lineStart;
        var slack = Math.min(0.7, 0.25 + 0.12 * lineLen);   // caption timing is rough, so widen
        s = Math.max(h.lineStart - 0.3, h.start - pb - slack);
        e = Math.min(h.lineEnd + 0.3, h.end + pa + slack);
      }
      raw.push({ start: s, end: e, text: h.text, category: h.category, source: h.source, estimated: true });
    });

    raw.sort(function (a, b) { return a.start - b.start; });
    var merged = [];
    raw.forEach(function (iv) {
      iv.start = Math.max(0, iv.start);
      var prev = merged[merged.length - 1];
      if (prev && iv.start - prev.end <= settings.mergeGap) {
        prev.end = Math.max(prev.end, iv.end);
        prev.text += ", " + iv.text;
        if (prev.categories.indexOf(iv.category) < 0) prev.categories.push(iv.category);
        prev.estimated = prev.estimated || !!iv.estimated;
      } else {
        merged.push({ start: iv.start, end: iv.end, text: iv.text, categories: [iv.category],
          source: iv.source, estimated: !!iv.estimated });
      }
    });
    merged.forEach(function (m) {
      m.start = Math.round(m.start * 1000) / 1000;
      m.end = Math.round(m.end * 1000) / 1000;
    });
    return merged;
  }

  // Index of the interval containing t, or -1. Intervals are sorted and non-overlapping.
  function findInterval(intervals, t) {
    var lo = 0, hi = intervals.length - 1;
    while (lo <= hi) {
      var mid = (lo + hi) >> 1, iv = intervals[mid];
      if (t < iv.start) hi = mid - 1;
      else if (t >= iv.end) lo = mid + 1;
      else return mid;
    }
    return -1;
  }

  // Censor matching words in a piece of on-screen caption text.
  // Must be idempotent: censorText(censorText(x)) === censorText(x), or the
  // on-screen caption observer would keep rewriting its own output.
  function censorText(text, rules) {
    var toks = tokenize(text);
    var hits = matchTokens(toks, rules);
    if (!hits.length) return { text: text, hit: false };
    var out = text;
    for (var h = hits.length - 1; h >= 0; h--) {
      for (var i = hits[h].last; i >= hits[h].first; i--) {
        var t = toks[i];
        if (isCensoredToken(t.norm)) continue;           // "[ __ ]" or "f***": nothing to hide
        var m = /^([^A-Za-z0-9_*]*)(.*?)([^A-Za-z0-9_*]*)$/.exec(t.raw);  // keep punctuation around the word
        out = out.slice(0, t.cs) + m[1] + censor(m[2]) + m[3] + out.slice(t.ce);
      }
    }
    return { text: out, hit: true };
  }

  function fmtTime(s) {
    s = Math.max(0, s);
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = Math.floor(s % 60);
    return (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(sec).padStart(2, "0");
  }

  // ------------------------------------------------------------- streaming subtitle files
  // Netflix / Prime serve TTML (XML), Disney+ / Max serve WebVTT. Both become
  // [{start, end, text}] cues, then a json3-like "track" so buildIntervals can
  // treat them like uploader captions (line timing, word position estimated).

  function decodeEntities(s) {
    return s.replace(/&#x([0-9a-f]+);/gi, function (m, h) { return String.fromCharCode(parseInt(h, 16)); })
      .replace(/&#(\d+);/g, function (m, d) { return String.fromCharCode(+d); })
      .replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
  }

  function ttmlTime(v, tickRate, frameRate) {
    if (!v) return null;
    v = v.trim();
    var m;
    if ((m = /^([\d.]+)t$/.exec(v))) return +m[1] / (tickRate || 1);
    if ((m = /^([\d.]+)ms$/.exec(v))) return +m[1] / 1000;
    if ((m = /^([\d.]+)s$/.exec(v))) return +m[1];
    if ((m = /^([\d.]+)m$/.exec(v))) return +m[1] * 60;
    if ((m = /^([\d.]+)h$/.exec(v))) return +m[1] * 3600;
    if ((m = /^(\d+):(\d{2}):(\d{2})(?:([.,]\d+)|:(\d+))?$/.exec(v))) {
      var s = (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]);
      if (m[4]) s += parseFloat(m[4].replace(",", "."));
      if (m[5]) s += (+m[5]) / (frameRate || 30);
      return s;
    }
    return null;
  }

  function parseTTML(xml) {
    var tick = /tickRate="(\d+)"/.exec(xml), fr = /frameRate="(\d+)"/.exec(xml);
    var tickRate = tick ? +tick[1] : 10000000, frameRate = fr ? +fr[1] : 30;
    var cues = [], re = /<(?:\w+:)?p\b([^>]*)>([\s\S]*?)<\/(?:\w+:)?p>/g, m;
    while ((m = re.exec(xml))) {
      var attrs = m[1];
      var b = /\bbegin="([^"]+)"/.exec(attrs), e = /\bend="([^"]+)"/.exec(attrs), d = /\bdur="([^"]+)"/.exec(attrs);
      var start = b ? ttmlTime(b[1], tickRate, frameRate) : null;
      var end = e ? ttmlTime(e[1], tickRate, frameRate) : (d && start !== null ? start + ttmlTime(d[1], tickRate, frameRate) : null);
      if (start === null || end === null) continue;
      var text = decodeEntities(m[2].replace(/<(?:\w+:)?br\s*\/?>/gi, " ").replace(/<[^>]+>/g, "")).replace(/\s+/g, " ").trim();
      if (text) cues.push({ start: start, end: end, text: text });
    }
    return cues;
  }

  function vttTime(v) {
    var m = /(?:(\d+):)?(\d{2}):(\d{2})[.,](\d{1,3})/.exec(v);
    if (!m) return null;
    return (+(m[1] || 0)) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / Math.pow(10, m[4].length);
  }

  function parseVTT(text) {
    // HLS segments: X-TIMESTAMP-MAP=MPEGTS:900000,LOCAL:00:00:00.000 moves cues onto the video timeline.
    var shift = 0, map = /X-TIMESTAMP-MAP=([^\r\n]+)/.exec(text);
    if (map) {
      var mp = /MPEGTS:(\d+)/.exec(map[1]), lc = /LOCAL:([\d:.,]+)/.exec(map[1]);
      if (mp) shift = (+mp[1]) / 90000 - (lc ? vttTime(lc[1]) || 0 : 0);
    }
    var cues = [], blocks = text.replace(/\r/g, "").split(/\n\s*\n/);
    blocks.forEach(function (block) {
      var lines = block.split("\n"), i = 0;
      while (i < lines.length && lines[i].indexOf("-->") < 0) i++;
      if (i >= lines.length) return;
      var parts = lines[i].split("-->");
      var s = vttTime(parts[0]), e = vttTime(parts[1] || "");
      if (s === null || e === null) return;
      var body = decodeEntities(lines.slice(i + 1).join(" ").replace(/<[^>]+>/g, "")).replace(/\s+/g, " ").trim();
      if (body) cues.push({ start: s + shift, end: e + shift, text: body });
    });
    cues.tsShift = shift;   // players usually subtract the stream's first timestamp; stream.js evens this out
    return cues;
  }

  // Detect and parse any subtitle file. Returns {kind, cues} or null.
  function parseSubtitles(text) {
    if (!text || typeof text !== "string") return null;
    var head = text.slice(0, 600);
    if (/^﻿?WEBVTT/.test(head)) { var vc = parseVTT(text); return { kind: "vtt", cues: vc, tsShift: vc.tsShift || 0 }; }
    if (/<(\w+:)?tt[\s>]/.test(head) && /ttml|<(\w+:)?p\b/.test(text)) return { kind: "ttml", cues: parseTTML(text), tsShift: 0 };
    return null;
  }

  // Cues -> the json3 shape buildIntervals understands (as "manual" line-timed captions).
  function cuesToTrack(cues) {
    return { events: cues.map(function (c) {
      return { tStartMs: Math.round(c.start * 1000), dDurationMs: Math.max(1, Math.round((c.end - c.start) * 1000)),
        segs: [{ utf8: c.text }] };
    }) };
  }

  // ------------------------------------------------------------- sound cues -> likely scenes
  // Subtitles written for deaf and hard-of-hearing viewers describe sounds: "[gunfire]",
  // "(moaning)". Bunches of these mark likely violent or sexual scenes. They're suggestions:
  // a lone [gunshot] isn't a scene, and some scenes are silent, so reviewers still confirm.
  //   [pattern, category, level (1 mild, 2 moderate, 3 graphic), weight]
  var SOUND_CUES = [
    [/\b(gun ?shots?|gunfire|gun fire|shots? (fired|ring out)|shooting|machine ?gun|rifle|pistol|bullets?|ricochets?)/, "violence", 2, 2],
    [/\b(explosions?|explodes|explosive|blast|bombs?)\b/, "violence", 2, 1.5],
    [/\b(punch(es|ing)?|kick(s|ing)?|fighting|fight|scuffl\w*|brawl\w*|slap(s|ping)?|struggl\w*|tackles?|grappl\w*|blows land|body hits)/, "violence", 1, 1],
    [/\b(stab(s|bing|bed)?|slash(es|ing)?|impal\w*|knife (slices|plunges)|blade (slices|pierces))/, "violence", 3, 3],
    [/\b(bones? (crack|snap|break|crunch)\w*|neck (snaps|cracks)|squelch\w*|splatter\w*|gore|dismember\w*|decapitat\w*|tortur\w*|flesh (tears|rips))/, "violence", 3, 3],
    [/\b(scream(s|ing)?|shriek\w*|wail(s|ing)?|cries out|yelps?)\b/, "violence", 1, 1],
    [/\b(in pain|agoniz\w*|chok(es|ing)|gurgl\w*|gasping for (air|breath)|strangl\w*|coughs? (up )?blood|bleeding|blood)/, "violence", 2, 2],
    [/\b(dying|death rattle|last breath|body (falls|thuds|drops|collapses))/, "violence", 2, 1.5],
    [/\b(moan(s|ing)?|orgasm\w*|climax(es|ing)?|(groan|sigh)(s|ing)? (with|in) pleasure)/, "sexual", 2, 2.5],
    [/\b(pant(s|ing)?|breathing heavily|heavy breathing|breathes heavily|breathless)/, "sexual", 1, 1],
    [/\b(bed (creak|squeak|rock|thump)\w*|headboard|(bed )?springs? (creak|squeak)\w*)/, "sexual", 2, 2.5],
    [/\b(kiss(es|ing)? (passionately|deeply|hungrily)|making out|passionate kiss\w*|smooch\w*)/, "sexual", 1, 1.5],
    [/\b(sensual|sultry|seductive|erotic|steamy) music/, "sexual", 1, 1.5],
    [/\b(having sex|sex|lovemaking|making love|thrust(s|ing)?)\b/, "sexual", 2, 3],
    [/\b(undress\w*|unzips?|unbuckl\w*|takes off (her|his|their) (shirt|dress|clothes|bra|top|pants))/, "sexual", 1, 1.5]
  ];
  // Words that make a "violent" sound harmless: [kids screaming playfully], [fireworks blast].
  var CUE_HARMLESS = /\b(laugh\w*|playful\w*|excited\w*|cheer\w*|happ\w*|joy\w*|delight\w*|firework\w*|on tv|on the tv|on television|radio|video game|in the distance|distant|music|song|singing|applause|crowd)\b/;
  var CUE_IGNORE = /\b(in the distance|distant|on tv|on the tv|on television|radio|video game|firework\w*)\b/;
  var LEVEL_NAMES = { 1: "mild", 2: "moderate", 3: "graphic" };

  // Bracketed/parenthesised sound descriptions in subtitle cues -> classified hits.
  function soundCueHits(cues) {
    var hits = [];
    (cues || []).forEach(function (c) {
      var re = /\[([^\]]{2,80})\]|\(([^)]{2,80})\)/g, m;
      while ((m = re.exec(c.text || ""))) {
        var t = (m[1] || m[2]).toLowerCase().replace(/\s+/g, " ").trim();
        for (var i = 0; i < SOUND_CUES.length; i++) {
          var rule = SOUND_CUES[i];
          if (!rule[0].test(t)) continue;
          var weight = rule[3];
          if (rule[1] === "violence" && CUE_HARMLESS.test(t)) weight = CUE_IGNORE.test(t) ? 0 : weight / 2;
          if (weight > 0) hits.push({ start: c.start, end: c.end, text: "[" + t + "]", category: rule[1], level: rule[2], weight: weight });
          break;
        }
      }
    });
    return hits.sort(function (a, b) { return a.start - b.start; });
  }

  // Groups nearby hits of the same kind into likely scenes.
  //   opts: gap (s between cues in one scene), before/after (padding), minScore
  function detectScenes(cues, opts) {
    opts = Object.assign({ gap: 12, before: 3, after: 2, minScore: 3 }, opts || {});
    var groups = {}, out = [];
    soundCueHits(cues).forEach(function (h) {
      var list = groups[h.category] || (groups[h.category] = []);
      var g = list[list.length - 1];
      if (g && h.start - g.last <= opts.gap) {
        g.last = Math.max(g.last, h.end); g.score += h.weight; g.level = Math.max(g.level, h.level);
        if (g.cues.indexOf(h.text) < 0) g.cues.push(h.text);
      } else {
        list.push({ first: h.start, last: h.end, score: h.weight, level: h.level, cues: [h.text] });
      }
    });
    Object.keys(groups).forEach(function (cat) {
      groups[cat].forEach(function (g) {
        if (g.score < opts.minScore) return;
        out.push({ start: Math.max(0, Math.round((g.first - opts.before) * 100) / 100),
          end: Math.round((g.last + opts.after) * 100) / 100, category: cat, level: g.level,
          score: Math.round(g.score * 10) / 10, cues: g.cues.slice(0, 6) });
      });
    });
    return out.sort(function (a, b) { return a.start - b.start; });
  }

  // The level is saved in the label, so a scene shared to the database keeps it.
  function sceneLabel(scene) {
    return ("sound cues (" + (LEVEL_NAMES[scene.level] || "moderate") + "): " + scene.cues.join(" ")).slice(0, 200);
  }
  function sceneLevel(seg) {
    if (seg.level) return seg.level;
    var m = /^sound cues \((mild|moderate|graphic)\)/.exec(seg.label || "");
    return m ? { mild: 1, moderate: 2, graphic: 3 }[m[1]] : 3;   // scenes people tagged count as graphic
  }
  // Does the viewer want this scene handled? Violence has a minimum level.
  function sceneWanted(seg, settings) {
    settings = settings || DEFAULT_SETTINGS;
    var cats = settings.categories || DEFAULT_SETTINGS.categories;
    if (cats[seg.category] === false) return false;
    if (seg.category === "violence") return sceneLevel(seg) >= (+settings.violenceLevel || 2);
    return true;
  }

  // ------------------------------------------------------------- shared database helpers

  // Which database segments to use: verified (approved) ones, your own, and - if the
  // viewer allows it - unverified ones from other people.
  function usableSegments(db, settings) {
    var segs = (db && db.segments) || [];
    var useUnverified = !settings || settings.useUnverified !== false;
    return segs.filter(function (s) {
      return s.status === "approved" || s.mine || (s.status === "pending" && useUnverified);
    });
  }

  // How trustworthy the database part of this title is, for telling the viewer.
  //   state: "none" (nothing from the database), "verified", "partial", "unverified",
  //          "hidden" (unverified timestamps exist but the viewer turned them off)
  function verification(db, used) {
    if (!db) return { state: "none", verified: 0, unverified: 0, hidden: 0 };
    var v = 0, u = 0;
    (used || []).forEach(function (s) { if (s.status === "approved") v++; else u++; });
    var counts = db.counts || {};
    var hidden = Math.max(0, (counts.unverified || 0) - u);
    var state = !v && !u ? (hidden ? "hidden" : "none") : !u ? "verified" : !v ? "unverified" : "partial";
    return { state: state, verified: v, unverified: u, hidden: hidden };
  }

  function verificationMessage(info, what) {
    what = what || "this title";
    if (!info) return null;
    if (info.state === "unverified") return "Not verified: the shared timestamps for " + what + " haven't been checked by a verified reviewer yet.";
    if (info.state === "partial") return info.unverified + " of " + (info.verified + info.unverified) +
      " timestamps for " + what + " aren't verified yet.";
    if (info.state === "hidden") return what.charAt(0).toUpperCase() + what.slice(1) + " has " + info.hidden +
      " unverified timestamp" + (info.hidden === 1 ? "" : "s") + " (not used - turn on \"Use unverified timestamps\" to use them).";
    if (info.state === "verified") return "Timestamps verified by a reviewer.";
    return null;
  }

  // Database segments -> mute intervals in the same shape buildIntervals makes.
  function segmentsToIntervals(segs, settings) {
    var cats = (settings && settings.categories) || DEFAULT_SETTINGS.categories;
    return segs.filter(function (s) {
      if (s.action !== "mute") return false;
      if (s.category === "custom") return true;
      if (s.category === "censored") return cats.strong !== false;
      return cats[s.category] !== false;
    }).map(function (s) {
      return { start: s.start, end: s.end, text: s.label || "", categories: [s.category], estimated: false,
        fromDatabase: true, unverified: s.status !== "approved" };
    });
  }

  // Join two sorted interval lists, merging overlaps (keeps findInterval's binary search valid).
  function mergeIntervals(a, b) {
    var all = (a || []).concat(b || []).sort(function (x, y) { return x.start - y.start; }), out = [];
    all.forEach(function (iv) {
      var p = out[out.length - 1];
      if (p && iv.start <= p.end + 0.05) {
        p.end = Math.max(p.end, iv.end);
        iv.categories.forEach(function (c) { if (p.categories.indexOf(c) < 0) p.categories.push(c); });
        if (iv.unverified) p.unverified = true;
        if (iv.fromDatabase) p.fromDatabase = true;
      } else {
        out.push(Object.assign({}, iv, { categories: iv.categories.slice() }));
      }
    });
    return out;
  }

  // What gets shared (with consent): built with the standard settings, all swear
  // categories, and none of the viewer's personal custom/allow words, so it is the same
  // for everyone and says nothing about the viewer's own preferences.
  var SHARE_SETTINGS = Object.assign({}, DEFAULT_SETTINGS, {
    categories: { strong: true, mild: true, blasphemy: true, slurs: true },
    custom: "", allow: "", uploaderMode: "word"
  });
  function shareableMutes(tracks, source) {
    var CAT_OK = { strong: 1, mild: 1, blasphemy: 1, slurs: 1, censored: 1 };
    return buildIntervals(tracks, SHARE_SETTINGS).map(function (iv) {
      var cat = iv.categories.filter(function (c) { return CAT_OK[c]; })[0];
      return cat ? { start: Math.round(iv.start * 1000) / 1000, end: Math.round(iv.end * 1000) / 1000,
        action: "mute", category: cat, label: String(iv.text || "").slice(0, 60), source: source } : null;
    }).filter(Boolean);
  }

  // ------------------------------------------------------------- free trial / plan
  // usage: { total, unsynced } seconds counted on this device
  // plan:  my_plan() from the database (or null), config: get_config() (or null)
  // While the paywall is off (the default) nothing is ever blocked.
  function entitlement(usage, plan, config) {
    config = config || {};
    usage = usage || { total: 0, unsynced: 0 };
    var paywall = config.paywall_enabled === true;
    var total = Math.round((+config.trial_hours || 2) * 3600);
    var signedIn = !!(plan && plan.signed_in);
    var used = signedIn ? (plan.trial_seconds_used || 0) + (usage.unsynced || 0) : (usage.total || 0);
    var subscribed = !!(plan && plan.subscribed);
    return {
      allowed: !paywall || subscribed || used < total,
      paywall: paywall, subscribed: subscribed, signedIn: signedIn,
      used: used, total: total, remaining: Math.max(0, total - used),
      planName: config.plan_name || "HushPlay Plus", priceLabel: config.price_label || null,
      subscribeUrl: config.subscribe_url || null
    };
  }

  function trialLine(e) {
    if (!e || !e.paywall) return null;
    if (e.subscribed) return e.planName + " · active";
    function span(sec) {
      if (sec >= 3600) { var h = Math.round(sec / 360) / 10; return h + (h === 1 ? " hour" : " hours"); }
      var m = Math.max(1, Math.ceil(sec / 60)); return m + (m === 1 ? " minute" : " minutes");
    }
    if (e.remaining <= 0) return "Your free trial (" + span(e.total) + ") is used up. Subscribe to keep filtering.";
    return "Free trial: " + span(e.remaining) + " left";
  }

  function canShare(settings) {
    return !!(settings && settings.shareFindings && settings.shareConsentAt);
  }

  // ------------------------------------------------------------- filter profiles
  // A profile holds what is filtered and how. Things about this device (on/off, the
  // database and sharing choices) stay on the device and aren't part of a profile.
  var PROFILE_KEYS = ["categories", "sceneCategory", "soundCues", "violenceLevel", "useSubtitles", "useUnverified",
    "custom", "allow", "padBefore", "padAfter", "uploaderMode", "censorCaptions", "showIndicator", "showBubble", "bubbleOpacity"];

  function profileSettings(settings) {
    var s = Object.assign({}, DEFAULT_SETTINGS, settings || {}), out = {};
    PROFILE_KEYS.forEach(function (k) {
      out[k] = k === "categories" ? Object.assign({}, DEFAULT_SETTINGS.categories, s.categories || {}) : s[k];
    });
    return out;
  }

  // settings with a profile's choices laid over them (unknown keys in the profile are ignored)
  function applyProfile(settings, profileValues) {
    var out = Object.assign({}, DEFAULT_SETTINGS, settings || {}), p = profileValues || {};
    PROFILE_KEYS.forEach(function (k) {
      if (!(k in p)) return;
      out[k] = k === "categories" ? Object.assign({}, DEFAULT_SETTINGS.categories, p.categories || {}) : p[k];
    });
    return out;
  }

  function sameProfileSettings(a, b) {
    return JSON.stringify(profileSettings(a)) === JSON.stringify(profileSettings(b));
  }

  var api = {
    PROFILE_KEYS: PROFILE_KEYS, profileSettings: profileSettings, applyProfile: applyProfile,
    sameProfileSettings: sameProfileSettings,
    usableSegments: usableSegments, verification: verification, verificationMessage: verificationMessage,
    segmentsToIntervals: segmentsToIntervals, mergeIntervals: mergeIntervals,
    shareableMutes: shareableMutes, canShare: canShare, entitlement: entitlement, trialLine: trialLine,
    parseSubtitles: parseSubtitles, cuesToTrack: cuesToTrack,
    soundCueHits: soundCueHits, detectScenes: detectScenes, sceneLabel: sceneLabel, sceneLevel: sceneLevel,
    sceneWanted: sceneWanted, LEVEL_NAMES: LEVEL_NAMES,
    CATEGORIES: CATEGORIES, DEFAULT_SETTINGS: DEFAULT_SETTINGS,
    normalize: normalize, censor: censor, compileRules: compileRules, matchTokens: matchTokens,
    tokenize: tokenize, parseTrack: parseTrack, buildIntervals: buildIntervals,
    findInterval: findInterval, censorText: censorText, fmtTime: fmtTime
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.VirtueCore = api;
})(typeof self !== "undefined" ? self : this);
