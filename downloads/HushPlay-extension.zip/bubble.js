/*
 * HushPlay - the round "H" button on the video (YouTube and movie/TV sites)
 *
 * Shows how many mutes and skips this video has. Click it for the list of what
 * gets muted or skipped and when; click a line to jump to 3 seconds before it.
 * It appears while the mouse is over the video (like the player's own controls)
 * and works in fullscreen. It lives in a shadow root so the site's styles can't
 * touch it, and clicks inside it never reach the player (no accidental pause).
 *
 *   var b = HushBubble.create({
 *     items: function () -> { list: [{ start, end, kind: "mute"|"skip"|"hint", text, chips: [[label, tone, tip]] }],
 *                             now: seconds, note: "optional line under the title" },
 *     seek: function (t) {},
 *     video: function () -> <video> or null,
 *     shown: function () -> false to hide it (filtering off, setting off, trial over),
 *     opacity: function () -> 0.2-1, how see-through the button is when you're not using it (optional)
 *   });
 *   b.refresh()   // after the list changes
 */
(function (root) {
  "use strict";
  if (root.HushBubble) return;

  var ICON = { mute: "\u{1F507}", skip: "⏭", hint: "⚠" };
  var KIND = { mute: "Muted", skip: "Skipped", hint: "Possible scene" };

  var CSS = [
    ":host { all: initial; }",
    ".wrap { position: fixed; z-index: 2147483646; font: 13px/1.35 system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;",
    "  color: #f2f2f2; transition: opacity .25s; }",
    ".wrap.hide { opacity: 0; pointer-events: none; }",
    ".fab { width: 44px; height: 44px; border-radius: 50%; border: 0; background: #2f6f5e; color: #fff; cursor: pointer;",
    "  font: 700 20px/44px system-ui, sans-serif; box-shadow: 0 2px 10px rgba(0,0,0,.45); position: relative; padding: 0; }",
    ".fab { opacity: var(--op, 1); transition: opacity .2s; }",
    ".fab:hover, .fab[aria-expanded=true], .fab:focus-visible { background: #3a8571; opacity: 1; }",
    ".fab:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }",
    ".fab .n { position: absolute; top: -4px; right: -4px; min-width: 18px; height: 18px; padding: 0 4px; box-sizing: border-box;",
    "  border-radius: 9px; background: #fff; color: #2f6f5e; font: 700 11px/18px system-ui, sans-serif; text-align: center; }",
    ".fab .n:empty { display: none; }",
    ".panel { position: absolute; right: 0; bottom: 54px; width: 320px; max-width: calc(100vw - 24px); max-height: min(60vh, 420px);",
    "  display: flex; flex-direction: column; background: rgba(24,24,26,.97); border: 1px solid #3a3a3e; border-radius: 12px;",
    "  box-shadow: 0 8px 28px rgba(0,0,0,.55); overflow: hidden; }",
    ".panel[hidden] { display: none; }",
    ".head { display: flex; align-items: center; gap: 8px; padding: 10px 12px 8px; border-bottom: 1px solid #333; }",
    ".head b { flex: 1; font-size: 14px; }",
    ".x { background: none; border: 0; color: #aaa; font-size: 16px; cursor: pointer; padding: 2px 6px; border-radius: 6px; }",
    ".x:hover { background: #333; color: #fff; }",
    ".note { padding: 6px 12px 0; color: #aaa; font-size: 12px; }",
    "ol { list-style: none; margin: 0; padding: 6px; overflow-y: auto; }",
    "li { display: flex; align-items: center; gap: 8px; padding: 6px 8px; border-radius: 8px; cursor: pointer; }",
    "li:hover { background: #2c2c30; }",
    "li.past { opacity: .45; }",
    "li.now { background: #1f3b33; }",
    "time { font-variant-numeric: tabular-nums; color: #7fd1b8; min-width: 44px; }",
    ".ic { width: 18px; text-align: center; }",
    ".t { flex: 1; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }",
    ".chip { font-size: 11px; padding: 1px 6px; border-radius: 9px; background: #333; color: #ccc; white-space: nowrap; }",
    ".chip.warn { background: #4a3500; color: #ffcf66; }",
    ".empty { padding: 14px 12px; color: #aaa; }",
    ".foot { padding: 6px 12px 9px; color: #888; font-size: 11px; border-top: 1px solid #333; }"
  ].join("\n");

  function fmt(t) {
    t = Math.max(0, Math.floor(t || 0));
    var h = Math.floor(t / 3600), m = Math.floor(t / 60) % 60, s = t % 60;
    return (h ? h + ":" + (m < 10 ? "0" : "") : "") + m + ":" + (s < 10 ? "0" : "") + s;
  }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  function create(o) {
    var hostEl = document.createElement("hushplay-bubble");
    var shadow = hostEl.attachShadow({ mode: "open" });
    var style = el("style"); style.textContent = CSS; shadow.appendChild(style);
    var wrap = el("div", "wrap hide");
    var fab = el("button", "fab", "H");
    fab.type = "button";
    fab.title = "HushPlay: what's muted and skipped";
    fab.setAttribute("aria-label", "HushPlay: show what's muted and skipped");
    var count = el("span", "n"); fab.appendChild(count);
    var panel = el("div", "panel"); panel.hidden = true;
    var head = el("div", "head"), title = el("b", null, "HushPlay"), x = el("button", "x", "✕");
    x.type = "button"; x.title = "Close"; x.setAttribute("aria-label", "Close");
    head.appendChild(title); head.appendChild(x);
    var note = el("div", "note"), list = el("ol"), empty = el("div", "empty"), foot = el("div", "foot", "Click a line to jump to 3 seconds before it.");
    panel.appendChild(head); panel.appendChild(note); panel.appendChild(list); panel.appendChild(empty); panel.appendChild(foot);
    wrap.appendChild(panel); wrap.appendChild(fab);
    shadow.appendChild(wrap);

    // Keep clicks and keys away from the player underneath.
    ["click", "dblclick", "mousedown", "mouseup", "pointerdown", "pointerup", "touchstart", "wheel", "keydown", "keyup", "keypress"].forEach(function (ev) {
      hostEl.addEventListener(ev, function (e) {
        e.stopPropagation();
        if (ev === "keydown" && e.key === "Escape") close();
      });
    });

    var open = false, lastMove = 0, lastSig = "";
    function close() { open = false; panel.hidden = true; fab.setAttribute("aria-expanded", "false"); tick(); }
    fab.addEventListener("click", function () {
      open = !open; panel.hidden = !open; fab.setAttribute("aria-expanded", String(open));
      lastSig = ""; render(); tick();
    });
    x.addEventListener("click", close);
    document.addEventListener("keydown", function (e) { if (open && e.key === "Escape") close(); }, true);

    document.addEventListener("mousemove", function (e) {
      var v = o.video();
      if (!v) return;
      var r = v.getBoundingClientRect();
      if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) lastMove = Date.now();
    }, { passive: true, capture: true });

    function data() { try { return o.items() || { list: [] }; } catch (e) { return { list: [] }; } }

    function render() {
      var d = data(), items = d.list || [], now = d.now || 0;
      var nMute = 0, nSkip = 0, nHint = 0;
      items.forEach(function (it) { if (it.kind === "skip") nSkip++; else if (it.kind === "hint") nHint++; else nMute++; });
      count.textContent = items.length ? String(items.length > 99 ? "99+" : items.length) : "";
      if (!open) return;
      var parts = [];
      if (nMute) parts.push(nMute + " mute" + (nMute === 1 ? "" : "s"));
      if (nSkip) parts.push(nSkip + " skip" + (nSkip === 1 ? "" : "s"));
      if (nHint) parts.push(nHint + " possible scene" + (nHint === 1 ? "" : "s"));
      title.textContent = "HushPlay" + (parts.length ? " · " + parts.join(", ") : "");
      note.textContent = d.note || ""; note.hidden = !d.note;
      // Only rebuild the rows when something changed (keeps the scroll position).
      var sig = items.length + "|" + Math.floor(now) + "|" + items.map(function (it) { return it.start + it.kind; }).join(",");
      if (sig === lastSig) return;
      var keepScroll = list.scrollTop;
      lastSig = sig;
      list.textContent = "";
      empty.hidden = items.length > 0;
      foot.hidden = !items.length;
      empty.textContent = d.empty || "Nothing to mute or skip in this video so far.";
      items.forEach(function (it) {
        var li = el("li");
        if (it.end < now) li.className = "past";
        else if (it.start <= now) li.className = "now";
        li.title = KIND[it.kind] + " · jump to 3 seconds before";
        li.appendChild(el("time", null, fmt(it.start)));
        li.appendChild(el("span", "ic", ICON[it.kind] || ICON.mute));
        li.appendChild(el("span", "t", it.text || KIND[it.kind]));
        (it.chips || []).forEach(function (c) {
          var ch = el("span", "chip" + (c[1] ? " " + c[1] : ""), c[0]);
          if (c[2]) ch.title = c[2];
          li.appendChild(ch);
        });
        li.addEventListener("click", function () { o.seek(Math.max(0, it.start - 3)); });
        list.appendChild(li);
      });
      list.scrollTop = keepScroll;
    }

    function tick() {
      var v = o.video(), ok = !!v && o.shown() !== false;
      if (!ok) { open = false; panel.hidden = true; }
      var h = document.fullscreenElement || document.body || document.documentElement;
      if (ok && hostEl.parentNode !== h) h.appendChild(hostEl);
      if (!ok) { wrap.classList.add("hide"); return; }
      var r = v.getBoundingClientRect();
      if (r.width < 200 || r.height < 120) { wrap.classList.add("hide"); return; }
      // Bottom-right of the video, above the player's control bar.
      var right = Math.max(8, window.innerWidth - r.right + 16);
      var bottom = Math.max(8, window.innerHeight - r.bottom + Math.min(84, r.height * 0.18));
      wrap.style.right = right + "px";
      wrap.style.bottom = bottom + "px";
      var op = o.opacity ? +o.opacity() : 1;
      wrap.style.setProperty("--op", String(op >= 0.2 && op <= 1 ? op : 1));
      var visible = open || Date.now() - lastMove < 3000;
      wrap.classList.toggle("hide", !visible);
      if (visible) render();
    }
    setInterval(tick, 400);
    document.addEventListener("fullscreenchange", tick);

    return { refresh: function () { lastSig = ""; render(); tick(); }, close: close };
  }

  root.HushBubble = { create: create, fmt: fmt };
})(typeof self !== "undefined" ? self : this);
