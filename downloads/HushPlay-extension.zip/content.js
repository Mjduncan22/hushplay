/*
 * HushPlay - content script (YouTube)
 * Receives caption tracks from page.js, works out when to mute, and mutes.
 * Also adds any mutes from the shared database, says when those aren't verified,
 * and (only if the viewer agreed) shares the swears it found with the database.
 *
 * Muting is done with a Web Audio gain node scheduled ahead of time, so it is
 * precise to a few milliseconds and keeps working when the tab is in the
 * background. If that isn't available yet, it falls back to video.muted.
 */
(function () {
  "use strict";
  var C = window.VirtueCore;
  var settings = Object.assign({}, C.DEFAULT_SETTINGS);
  var rules = C.compileRules(settings);

  var state = blank(null, "idle");
  function blank(id, phase) {
    return { videoId: id, phase: phase, error: null, tracks: [], intervals: [], sources: [],
      db: null, dbFor: null, verify: C.verification(null, []), shared: null };
  }

  // ------------------------------------------------------------------ settings

  // The same engine runs in the Chrome extension and in the phone app.
  // "Host" is how it gets settings and talks to whichever one it's in.
  var Host = window.__VIRTUE_HOST || {
    getSettings: function (cb) {
      try { chrome.storage.sync.get("settings", function (r) { cb((r && r.settings) || {}); }); }
      catch (e) { cb({}); }
    },
    onSettingsChanged: function (cb) {
      try {
        chrome.storage.onChanged.addListener(function (ch) { if (ch.settings) cb(ch.settings.newValue || {}); });
      } catch (e) {}
    },
    onRequest: function (handler) {
      chrome.runtime.onMessage.addListener(function (msg, sender, reply) { reply(handler(msg)); return true; });
    },
    notify: function () {},
    // Shared database (via background.js). cb(result or null)
    lookup: function (service, id, cb) {
      try {
        chrome.runtime.sendMessage({ type: "db", op: "lookup", args: [service, id] }, function (r) {
          if (chrome.runtime.lastError) { cb(null); return; }
          cb(r && r.ok ? r.res : null);
        });
      } catch (e) { cb(null); }
    },
    share: function (service, id, title, segments, cb) {
      try {
        chrome.runtime.sendMessage({ type: "db", op: "share", args: [service, id, title, segments] }, function (r) {
          if (chrome.runtime.lastError) { cb && cb(null); return; }
          cb && cb(r && r.ok ? r.res : { shared: 0, reason: r && r.error });
        });
      } catch (e) { cb && cb(null); }
    },
    // Free trial: report filtered watching time; ask whether filtering is allowed.
    reportUsage: function (seconds) {
      try { chrome.runtime.sendMessage({ type: "virtue-usage", seconds: seconds }, function () { void chrome.runtime.lastError; }); } catch (e) {}
    },
    entitlement: function (cb) {
      try {
        chrome.runtime.sendMessage({ type: "virtue-entitlement" }, function (r) {
          if (chrome.runtime.lastError) { cb(null); return; }
          cb(r || null);
        });
      } catch (e) { cb(null); }
    }
  };

  function applySettings(s) {
    s = s || {};
    settings = Object.assign({}, C.DEFAULT_SETTINGS, s);
    settings.categories = Object.assign({}, C.DEFAULT_SETTINGS.categories, s.categories || {});
    rules = C.compileRules(settings);
  }

  function loadSettings(cb) {
    Host.getSettings(function (s) { applySettings(s); if (cb) cb(); });
  }

  Host.onSettingsChanged(function (s) {
    var oldLang = settings.language;
    applySettings(s);
    if (settings.language !== oldLang) requestReload();
    if (state.videoId && settings.useDatabase && state.dbFor !== state.videoId) lookupDb(state.videoId);
    rebuild();
    if (state.phase === "ready") shareFinds();   // e.g. sharing was just turned on
  });

  function requestReload() {
    window.postMessage({ source: "virtue-content", type: "reload", language: settings.language }, "*");
  }

  // ------------------------------------------------------------------ captions in

  window.addEventListener("message", function (e) {
    if (e.source !== window || !e.data || e.data.source !== "virtue-page") return;
    var d = e.data;
    if (d.type === "status" && d.state === "loading") {
      state = blank(d.videoId, "loading");
      needsSchedule = true;
      lookupDb(d.videoId);
      Host.notify(statusSnapshot());
    } else if (d.type === "tracks") {
      state.videoId = d.videoId;
      state.tracks = d.tracks || [];
      state.error = d.error || null;
      state.phase = !d.videoId ? "idle" : (state.tracks.length ? "ready" : "error");
      if (d.videoId && state.dbFor !== d.videoId) lookupDb(d.videoId);
      rebuild();
      if (d.videoId) { announce(); shareFinds(); }
    }
  });

  // Shared database: tags people added for this video (e.g. swears the captions miss).
  function lookupDb(id) {
    if (!id || !settings.useDatabase || !Host.lookup) return;
    state.dbFor = id;
    Host.lookup("youtube", id, function (res) {
      if (state.videoId !== id) return;
      state.db = res || null;
      rebuild();
      if (state.db && state.verify.state !== "none") announce();
    });
  }

  function rebuild() {
    var fromCaptions = state.tracks.length ? C.buildIntervals(state.tracks, settings) : [];
    var used = settings.useDatabase ? C.usableSegments(state.db, settings) : [];
    state.verify = settings.useDatabase ? C.verification(state.db, used) : C.verification(null, []);
    state.intervals = C.mergeIntervals(fromCaptions, C.segmentsToIntervals(used, settings));
    state.sources = state.tracks.map(function (t) { return t.kind; });
    if (state.intervals.some(function (iv) { return iv.fromDatabase; })) state.sources = state.sources.concat(["database"]);
    needsSchedule = true;
    Host.notify(statusSnapshot());
  }

  // With the viewer's consent only: send the swear timestamps found in this video's
  // captions (times, category, the censored word) - never the captions themselves.
  function shareFinds() {
    if (!C.canShare(settings) || !Host.share || !state.tracks.length || state.shared) return;
    var id = state.videoId, segs = C.shareableMutes(state.tracks, "captions");
    state.shared = { pending: true };
    if (!segs.length) { state.shared = { shared: 0, reason: "nothing-found" }; return; }
    var name = (document.title || "").replace(/\s*-\s*YouTube\s*$/, "").replace(/^\(\d+\)\s*/, "").trim();
    Host.share("youtube", id, { name: name || ("YouTube " + id), kind: "video" }, segs, function (r) {
      if (state.videoId === id) { state.shared = r || { shared: 0, reason: "error" }; Host.notify(statusSnapshot()); }
    });
  }

  // ------------------------------------------------------------------ video + player

  function player() { return document.getElementById("movie_player"); }

  function video() {
    var p = player();
    return (p && p.querySelector("video.html5-main-video")) || (p && p.querySelector("video")) || null;
  }

  function adShowing() {
    var p = player();
    return !!(p && p.classList.contains("ad-showing"));
  }

  function currentVideoId() {
    var m = location.pathname.match(/^\/(?:shorts|embed|live)\/([\w-]{11})/);
    return m ? m[1] : new URLSearchParams(location.search).get("v");
  }

  // ------------------------------------------------------------------ audio

  var actx = null, gainNode = null, sources = new WeakMap(), routedVideo = null, audioBroken = false;
  var RAMP = 0.012;

  // iPhone/iPad and Safari: routing video audio through Web Audio can come out
  // silent there (Apple's media pipeline), so use direct muting with exact
  // timers instead. The phone app also sets __VIRTUE_BASIC_AUDIO on iOS.
  var UA = navigator.userAgent || "";
  var preferBasic = window.__VIRTUE_BASIC_AUDIO === true ||
    /iPhone|iPad|iPod/.test(UA) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1) ||
    (/AppleWebKit/.test(UA) && /Safari/.test(UA) && !/Chrome|Chromium|CriOS|FxiOS|Edg|OPR|Android/.test(UA));

  // wake = true only from a real click/keypress; ticks never create or resume audio.
  function audioReady(v, wake) {
    if (preferBasic || audioBroken || !v) return false;
    if (routedVideo === v && gainNode && actx.state === "running") return true;
    if (!actx && !wake) return false;
    try {
      if (!actx) {
        actx = new AudioContext();
        actx.onstatechange = function () {
          needsSchedule = true;
          // Once the video is routed through us, a suspended context would mean silence.
          if (routedVideo && actx.state === "suspended") actx.resume().catch(function () {});
        };
      }
      if (actx.state !== "running") {
        if (wake) actx.resume().then(function () { audioReady(video(), true); }).catch(function () {});
        return false;
      }
      if (!gainNode) { gainNode = actx.createGain(); gainNode.connect(actx.destination); }
      if (routedVideo !== v) {
        var src = sources.get(v);
        if (!src) { src = actx.createMediaElementSource(v); sources.set(v, src); }
        src.connect(gainNode);
        routedVideo = v;
        needsSchedule = true;
      }
      return true;
    } catch (e) {
      audioBroken = true;
      return false;
    }
  }

  // Wake audio on the first click/keypress (browsers require a user action).
  ["pointerdown", "keydown"].forEach(function (ev) {
    document.addEventListener(ev, function () { audioReady(video(), true); }, true);
  });

  // ------------------------------------------------------------------ the mute engine

  var needsSchedule = true, scheduledUntil = -1, anchor = null, weMuted = false, liveMuteUntil = 0;

  function active() {
    return settings.enabled && !locked && state.videoId && state.videoId === currentVideoId() && !adShowing();
  }

  // ------------------------------------------------------------------ free trial
  // Counts time spent watching with HushPlay filtering. Filtering only stops when the
  // paywall is switched on, the free hours are used up and there's no subscription.
  var locked = false, ent = null, usageSec = 0, lockedNoticeFor = null;
  function checkEntitlement() {
    if (!Host.entitlement) return;
    Host.entitlement(function (e) {
      if (!e) return;                       // can't tell: keep filtering
      ent = e;
      var was = locked;
      locked = !e.allowed;
      if (locked !== was) { needsSchedule = true; Host.notify(statusSnapshot()); }
    });
  }
  setInterval(checkEntitlement, 60000);
  setTimeout(checkEntitlement, 500);
  setInterval(function () {
    var v = video();
    if (v && !v.paused && settings.enabled && !locked && state.videoId && !adShowing()) usageSec++;
    if (usageSec >= 30 && Host.reportUsage) { Host.reportUsage(usageSec); usageSec = 0; }
    if (locked && state.videoId && lockedNoticeFor !== state.videoId && v && !v.paused) {
      lockedNoticeFor = state.videoId;
      notice(C.trialLine(ent) || "Your free trial is over. Subscribe to keep filtering.", 9000);
    }
  }, 1000);
  window.addEventListener("pagehide", function () { if (usageSec && Host.reportUsage) Host.reportUsage(usageSec); });

  function firstAfter(list, t) {
    var lo = 0, hi = list.length;
    while (lo < hi) { var mid = (lo + hi) >> 1; if (list[mid].start <= t) lo = mid + 1; else hi = mid; }
    return lo;
  }

  function schedule(v) {
    var g = gainNode.gain, now = actx.currentTime;
    var t = v.currentTime, rate = v.playbackRate || 1;
    var list = active() ? state.intervals : [];
    var idx = C.findInterval(list, t);
    var liveMute = active() && !list.length && performance.now() < liveMuteUntil;
    g.cancelScheduledValues(now);
    g.setValueAtTime(idx >= 0 || liveMute ? 0 : 1, now);
    anchor = { t: t, ctx: now, rate: rate, paused: v.paused };
    scheduledUntil = Infinity;
    if (!list.length || v.paused) return;

    var horizon = t + 3 * rate, last = now;
    var i = idx >= 0 ? idx : firstAfter(list, t);
    for (; i < list.length && list[i].start < horizon; i++) {
      var iv = list[i];
      if (iv.start > t) {
        var at = Math.max(last + 0.001, now + (iv.start - t) / rate);
        g.setValueAtTime(1, Math.max(last, at - RAMP));
        g.linearRampToValueAtTime(0, at);
        last = at;
      }
      if (iv.end >= horizon) break;
      var off = Math.max(last + 0.001, now + (iv.end - t) / rate);
      g.setValueAtTime(0, off);
      g.linearRampToValueAtTime(1, off + RAMP);
      last = off + RAMP;
    }
    scheduledUntil = horizon - 1.5 * rate;    // re-plan well before we run out
  }

  function drifted(v) {
    if (!anchor) return true;
    if (anchor.paused !== v.paused || anchor.rate !== (v.playbackRate || 1)) return true;
    if (v.paused) return Math.abs(v.currentTime - anchor.t) > 0.05;
    var expected = anchor.t + (actx.currentTime - anchor.ctx) * anchor.rate;
    return Math.abs(expected - v.currentTime) > 0.06;
  }

  function nearBoundary(t) {
    var list = state.intervals, i = firstAfter(list, t);
    var check = [list[i - 1], list[i]];
    return check.some(function (iv) {
      return iv && (Math.abs(iv.start - t) < 0.04 || Math.abs(iv.end - t) < 0.04);
    });
  }

  var lastAd = false, lastActive = null;
  function tick() {
    var v = video();
    if (!v) return;
    var act = active();
    if (act !== lastActive) { lastActive = act; needsSchedule = true; }
    var ad = adShowing();
    if (ad !== lastAd) { lastAd = ad; needsSchedule = true; }

    var basic = !(routedVideo === v && gainNode);
    // Basic mode acts a hair early so the change has landed by the word's edge.
    var lead = basic ? BASIC_LEAD * (v.playbackRate || 1) : 0;
    var inside = act && C.findInterval(state.intervals, v.currentTime + lead) >= 0;
    var live = act && !state.intervals.length && performance.now() < liveMuteUntil;

    if (audioReady(v)) {
      if (weMuted) { v.muted = false; weMuted = false; }   // hand over from fallback
      var t = v.currentTime;
      if (needsSchedule || drifted(v) || (t > scheduledUntil && !nearBoundary(t)) || live) {
        needsSchedule = false;
        schedule(v);
      }
    } else {
      // Basic mode: toggle the element's mute directly. Never unmutes anything
      // the viewer (or YouTube's muted autoplay) muted - only what we muted.
      var want = inside || live;
      if (want && !v.muted) { v.muted = true; weMuted = true; }
      else if (!want && weMuted) { v.muted = false; weMuted = false; }
      armBasicTimer(v, act);
    }
    showMuting(inside || live);

    // Debug readout for testing (only when the page sets data-virtue-debug).
    var root = document.documentElement;
    if (root.hasAttribute("data-virtue-debug")) {
      root.setAttribute("data-virtue-state", JSON.stringify({
        t: v.currentTime, gain: gainNode ? gainNode.gain.value : null, muted: v.muted,
        mode: routedVideo === v ? "precise" : "basic", n: state.intervals.length, phase: state.phase,
        sources: state.sources
      }));
    }
  }

  // Basic mode timing: the 25 ms tick alone could land up to 25 ms late, so when
  // the next mute edge is close, set a one-off timer for that exact moment.
  var BASIC_LEAD = 0.015, basicTimer = null, basicEdge = null;
  function armBasicTimer(v, act) {
    if (!act || v.paused || !state.intervals.length) {
      if (basicTimer) { clearTimeout(basicTimer); basicTimer = null; basicEdge = null; }
      return;
    }
    var rate = v.playbackRate || 1, t = v.currentTime + BASIC_LEAD * rate, list = state.intervals;
    var idx = C.findInterval(list, t);
    var edge = idx >= 0 ? list[idx].end : (list[firstAfter(list, t)] || {}).start;
    if (edge === undefined) return;
    var ms = (edge - t) / rate * 1000;
    if (ms > 60 || ms < 0 || basicEdge === edge) return;
    if (basicTimer) clearTimeout(basicTimer);
    basicEdge = edge;
    basicTimer = setTimeout(function () { basicTimer = null; tick(); basicEdge = null; }, ms);
  }

  setInterval(tick, 25);
  ["seeking", "seeked", "play", "pause", "ratechange", "waiting", "playing", "loadedmetadata"].forEach(function (ev) {
    document.addEventListener(ev, function (e) {
      if (e.target && e.target.tagName === "VIDEO") { needsSchedule = true; tick(); }
    }, true);
  });
  window.addEventListener("pagehide", function () { var v = video(); if (v && weMuted) v.muted = false; });

  // ------------------------------------------------------------------ on-screen captions

  // Watches only the video player (not the whole page), batches work to one
  // scan per animation frame, and has a circuit breaker: if it ever rewrites
  // captions more than 40 times in a second, caption censoring switches off
  // for this page instead of risking a freeze.
  var scanQueued = false, written = new WeakMap(), writeTimes = [], censorBroken = false;
  var observer = new MutationObserver(function () {
    if (scanQueued) return;
    scanQueued = true;
    requestAnimationFrame(function () { scanQueued = false; scanCaptions(); });
  });

  function scanCaptions() {
    var p = player();
    if (!p) return;
    var segs = p.querySelectorAll(".ytp-caption-segment");
    var anyHit = false;
    for (var i = 0; i < segs.length; i++) {
      var s = segs[i], text = s.textContent;
      if (written.get(s) === text) { anyHit = true; continue; }   // our own edit coming back
      var r = C.censorText(text, rules);
      if (!r.hit) continue;
      anyHit = true;
      if (settings.enabled && settings.censorCaptions && !censorBroken && r.text !== text) {
        var now = performance.now();
        writeTimes.push(now);
        while (writeTimes.length && now - writeTimes[0] > 1000) writeTimes.shift();
        if (writeTimes.length > 40) {
          censorBroken = true;
          console.warn("[HushPlay] caption censoring paused on this page (too many rewrites)");
          continue;
        }
        written.set(s, r.text);
        s.textContent = r.text;
      }
    }
    // Backup when the full caption track couldn't be loaded: mute while a bad line is on screen.
    if (anyHit) liveMuteUntil = performance.now() + 700;
  }

  var observedPlayer = null;
  function watchPlayer() {
    var p = player();
    if (p && p !== observedPlayer) {
      observer.disconnect();
      observer.observe(p, { childList: true, subtree: true, characterData: true });
      observedPlayer = p;
    }
  }
  setInterval(watchPlayer, 1000);
  watchPlayer();

  // ------------------------------------------------------------------ overlay

  var badge = null, toastTimer = null;

  function ensureBadge() {
    var p = player();
    if (!p) return null;
    if (badge && badge.parentNode === p) return badge;
    badge = document.createElement("div");
    badge.id = "virtue-badge";
    p.appendChild(badge);
    return badge;
  }

  function showMuting(on) {
    if (!settings.showIndicator) on = false;
    var b = on || (badge && badge.classList.contains("muting")) ? ensureBadge() : null;
    if (!b) return;
    b.classList.toggle("muting", !!on);
    if (on) b.textContent = "Muted";
    else if (!b.classList.contains("toast")) b.textContent = "";
  }

  var MESSAGES = {
    "no-captions": "This video has no captions, so swearing can't be filtered.",
    "no-language": "No captions in your language, so swearing can't be filtered.",
    "fetch-failed": "Couldn't load captions. Turn on CC to filter line by line.",
    "no-player": "Couldn't read this video's captions."
  };

  function notice(text, ms) {
    if (!settings.showIndicator) return;
    var b = ensureBadge();
    if (!b) return;
    b.textContent = text;
    b.classList.add("toast", "warn");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      b.classList.remove("toast", "warn");
      if (!b.classList.contains("muting")) b.textContent = "";
    }, ms || 7000);
  }

  function announce() {
    if (!settings.enabled || !settings.showIndicator || locked) return;
    var b = ensureBadge();
    if (!b) { setTimeout(announce, 500); return; }
    var n = state.intervals.length;
    var unverified = state.verify.state === "unverified" || state.verify.state === "partial";
    var text = state.phase === "ready" || n
      ? "HushPlay on · " + n + " mute" + (n === 1 ? "" : "s") + (unverified ? " · timestamps not verified" : "")
      : (MESSAGES[state.error] || "");
    if (!text) return;
    b.textContent = text;
    b.classList.add("toast");
    b.classList.toggle("warn", (state.phase !== "ready" && !n) || unverified);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      b.classList.remove("toast", "warn");
      if (!b.classList.contains("muting")) b.textContent = "";
    }, state.phase === "ready" && !unverified ? 3500 : 7000);
  }

  // ------------------------------------------------------------------ popup

  function statusSnapshot() {
    var v = video();
    return {
      videoId: state.videoId, phase: state.phase, error: state.error,
      message: MESSAGES[state.error] || null,
      sources: state.sources, intervals: state.intervals,
      verify: state.verify, verifyMessage: C.verificationMessage(state.verify, "this video"),
      inDatabase: !!state.db, shared: state.shared,
      locked: locked, entitlement: ent,
      audio: audioBroken ? "basic" : (actx && actx.state === "running" && routedVideo ? "precise" : "basic"),
      currentTime: v ? v.currentTime : 0
    };
  }

  Host.onRequest(function (msg) {
    if (msg.type === "status") {
      return statusSnapshot();
    } else if (msg.type === "seek") {
      var vv = video();
      if (vv) vv.currentTime = Math.max(0, msg.t);
      return { ok: true };
    } else if (msg.type === "reload") {
      requestReload();
      return { ok: true };
    }
    return null;
  });

  loadSettings(function () { requestReload(); });
})();
