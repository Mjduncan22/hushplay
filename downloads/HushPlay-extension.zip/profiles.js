/*
 * HushPlay - filter profiles, kept in sync with the account
 *
 * A profile ("Kids", "Movie night") is a named set of filter settings saved to the
 * account. Each device or app chooses one to follow, or keeps its own settings
 * ("this device only"). Devices following the same profile share changes.
 *
 *   var sync = VirtueProfiles.create({ db, core, store, getSettings, setSettings })
 *     getSettings() -> Promise<settings>   setSettings(settings) -> Promise
 *
 * The same file runs in the Chrome extension, the phone/TV app and Node tests.
 */
(function (root) {
  "use strict";

  var STATE_KEY = "virtue.profileState";
  var STALE_MS = 5 * 60 * 1000;

  function create(o) {
    var db = o.db, C = o.core, store = o.store;
    var pushTimer = null, lastPull = 0, busy = Promise.resolve();

    // Run one thing at a time so a pull and a push don't trip over each other.
    function serial(fn) {
      var run = busy.then(fn, fn);
      busy = run.catch(function () {});
      return run;
    }
    function hash(settings) { return JSON.stringify(C.profileSettings(settings)); }

    // { id: profile this device follows (null = this device only), name, chosen: picked by
    //   the person (else the account default is followed), at: profile version applied,
    //   pushed: the settings last sent or received }
    async function getState() {
      var s = null;
      try { s = await store.get(STATE_KEY); } catch (e) {}
      return Object.assign({ id: null, name: null, chosen: false, at: null, pushed: null }, s || {});
    }
    async function setState(s) { try { await store.set(STATE_KEY, s); } catch (e) {} return s; }

    async function signedIn() { return db.configured && (await db.signedIn()); }

    // Lay a profile's settings over this device's settings and remember what was applied.
    async function adopt(state, p) {
      var cur = await o.getSettings();
      var next = C.applyProfile(cur, p.settings);
      state.id = p.id; state.name = p.name; state.at = p.updated_at; state.pushed = hash(next);
      await setState(state);
      if (hash(cur) !== state.pushed) await o.setSettings(next);
      return state;
    }

    function result(state, profiles) {
      return { signedIn: true, activeId: state.id, activeName: state.name, chosen: state.chosen,
        profiles: (profiles || []).map(function (p) {
          return { id: p.id, name: p.name, isDefault: !!p.is_default, updatedAt: p.updated_at, settings: p.settings };
        }) };
    }

    // Get the latest from the account. A new account gets a first profile made from this
    // device's settings; a device that hasn't picked one follows the account's default.
    function pull() {
      return serial(async function () {
        lastPull = Date.now();
        var state = await getState();
        if (!(await signedIn())) return { signedIn: false, activeId: null, profiles: [] };
        var list = await db.profiles();
        if (!list.length) {
          var first = await db.saveProfile(null, "My settings", C.profileSettings(await o.getSettings()), true);
          list = [first];
          state.chosen = false;
        }
        // A change made here that hasn't been sent yet wins over the copy in the account.
        var unsent = state.id && state.pushed !== null && hash(await o.getSettings()) !== state.pushed;
        if (!state.chosen) {
          var def = list.filter(function (p) { return p.is_default; })[0] || list[0];
          if (def.id !== state.id) await adopt(state, def);
          else if (def.updated_at !== state.at && !unsent) await adopt(state, def);
          else if (def.name !== state.name) { state.name = def.name; await setState(state); }
        } else if (state.id) {
          var mine = list.filter(function (p) { return p.id === state.id; })[0];
          if (!mine) { state.id = null; state.name = null; state.at = null; await setState(state); }   // deleted elsewhere
          else if (mine.updated_at !== state.at && !unsent) await adopt(state, mine);
          else if (mine.name !== state.name) { state.name = mine.name; await setState(state); }
        }
        if (unsent && state.id) o.getSettings().then(function (s) { onLocalChange(s, 0).catch(function () {}); });   // e.g. the send was cut off
        return result(state, list);
      });
    }

    function pullIfStale() { return Date.now() - lastPull > STALE_MS ? pull().catch(function () {}) : Promise.resolve(); }

    // Local settings changed: send them to the profile this device follows (after a pause,
    // so dragging a slider doesn't send twenty updates).
    function onLocalChange(settings, waitMs) {
      clearTimeout(pushTimer);
      return new Promise(function (resolve) {
        pushTimer = setTimeout(function () { push(settings).then(resolve, function () { resolve(false); }); }, waitMs == null ? 1500 : waitMs);
      });
    }
    function push(settings) {
      return serial(async function () {
        var state = await getState();
        if (!state.id || hash(settings) === state.pushed || !(await signedIn())) return false;
        try {
          var p = await db.saveProfile(state.id, null, C.profileSettings(settings), false);
          state.at = p.updated_at; state.pushed = hash(settings); state.name = p.name;
          await setState(state);
          return true;
        } catch (e) {
          if (/not found/i.test(e.message)) { state.id = null; state.name = null; await setState(state); }
          throw e;
        }
      });
    }

    // Follow a profile on this device (id null = keep this device's own settings).
    function use(id) {
      return serial(async function () {
        var state = await getState();
        state.chosen = true;
        if (!id) { state.id = null; state.name = null; state.at = null; await setState(state); }
        else {
          var p = (await db.profiles()).filter(function (x) { return x.id === id; })[0];
          if (!p) throw new Error("That profile doesn't exist any more.");
          await adopt(state, p);
        }
        return result(state, await db.profiles());
      });
    }

    // New profile from this device's current settings (or the standard ones).
    function createProfile(name, opts) {
      opts = opts || {};
      return serial(async function () {
        var base = opts.fresh ? C.DEFAULT_SETTINGS : await o.getSettings();
        var p = await db.saveProfile(null, name, C.profileSettings(base), !!opts.makeDefault);
        return p;
      }).then(function (p) { return opts.use === false ? pull() : use(p.id); });
    }

    function rename(id, name) {
      return serial(function () { return db.saveProfile(id, name, null, false); }).then(pull);
    }
    function makeDefault(id) {
      return serial(function () { return db.saveProfile(id, null, null, true); }).then(pull);
    }
    function remove(id) {
      return serial(async function () {
        await db.deleteProfile(id);
        var state = await getState();
        if (state.id === id) { state.id = null; state.name = null; state.at = null; state.chosen = true; await setState(state); }
      }).then(pull);
    }

    // Signing out: keep the settings, stop following the account's profile.
    function signedOut() {
      clearTimeout(pushTimer);
      return serial(function () { return setState({ id: null, name: null, chosen: false, at: null, pushed: null }); });
    }

    return { pull: pull, pullIfStale: pullIfStale, onLocalChange: onLocalChange, push: push, use: use,
      create: createProfile, rename: rename, makeDefault: makeDefault, remove: remove, signedOut: signedOut,
      state: getState };
  }

  var api = { create: create };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.VirtueProfiles = api;
})(typeof self !== "undefined" ? self : this);
