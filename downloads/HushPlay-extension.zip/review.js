(function () {
  "use strict";
  var C = window.VirtueCore;
  var $ = function (id) { return document.getElementById(id); };
  var items = [];

  function db(op, args) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage({ type: "db", op: op, args: args }, function (r) {
        if (chrome.runtime.lastError || !r) reject(new Error("Extension background isn't responding."));
        else if (!r.ok) reject(new Error(r.error));
        else resolve(r.res);
      });
    });
  }

  function load() {
    $("summary").textContent = "Loading…";
    db("pending", [500]).then(function (list) {
      items = list || [];
      draw();
    }).catch(function (e) { $("summary").textContent = ""; $("msg").textContent = e.message; });
  }

  function titleOf(it) {
    if (it.series) return it.series + " · S" + (it.season || "?") + "E" + (it.episode || "?") + (it.name ? " · " + it.name : "");
    return it.name;
  }

  function draw() {
    var groups = {};
    items.forEach(function (it) { (groups[it.title_id] = groups[it.title_id] || []).push(it); });
    var box = $("groups");
    box.innerHTML = "";
    $("summary").textContent = items.length + " waiting for review";
    if (!items.length) { box.innerHTML = '<p class="empty">Nothing waiting. Nice.</p>'; return; }
    Object.keys(groups).forEach(function (tid) {
      var g = groups[tid], first = g[0];
      var sec = document.createElement("section");
      sec.className = "card group";
      var h = document.createElement("h3");
      h.textContent = titleOf(first) + " ";
      var src = document.createElement("span");
      src.className = "src";
      src.textContent = (first.sources || []).map(function (s) { return s.service + " #" + s.service_id; }).join(", ");
      h.appendChild(src);
      sec.appendChild(h);
      var table = document.createElement("table");
      g.sort(function (a, b) { return a.start - b.start; }).forEach(function (it) {
        var tr = document.createElement("tr");
        tr.innerHTML = '<td><input type="checkbox"></td><td class="t"></td><td></td><td></td><td></td><td class="who"></td>';
        tr.children[0].firstChild.dataset.id = it.id;
        tr.children[1].textContent = C.fmtTime(it.start) + "–" + C.fmtTime(it.end) + "  (" + (it.end - it.start).toFixed(1) + "s)";
        tr.children[2].textContent = it.action === "skip" ? "Skip" : "Mute";
        tr.children[3].textContent = it.category;
        tr.children[4].textContent = it.label || "";
        tr.children[5].textContent = (it.submitted_by || "someone") + " · " + it.source;
        table.appendChild(tr);
      });
      sec.appendChild(table);
      box.appendChild(sec);
    });
  }

  function selected() {
    return Array.prototype.map.call(document.querySelectorAll("#groups input:checked"), function (c) { return c.dataset.id; });
  }

  function decide(status) {
    var ids = selected();
    if (!ids.length) { $("msg").textContent = "Tick some rows first."; return; }
    $("msg").textContent = "Saving…";
    db("review", [ids, status]).then(function (n) {
      $("msg").textContent = n + (status === "approved" ? " approved" : " rejected") + ".";
      load();
    }).catch(function (e) { $("msg").textContent = e.message; });
  }

  $("approve").addEventListener("click", function () { decide("approved"); });
  $("reject").addEventListener("click", function () { decide("rejected"); });
  $("reload").addEventListener("click", load);
  $("selAll").addEventListener("click", function () {
    var boxes = document.querySelectorAll("#groups input[type=checkbox]");
    var all = Array.prototype.every.call(boxes, function (b) { return b.checked; });
    boxes.forEach(function (b) { b.checked = !all; });
  });
  load();
})();
